<?php
include '_con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect the input details from the POST request
    $doctor_id = $_POST['doctor_id'];
    $password = $_POST['password'];

    // Prepare the SQL statement to fetch doctor_id and name if credentials match
    $sql = "SELECT doctor_id, name FROM doctor WHERE doctor_id = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $doctor_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a matching record is found
    if ($result->num_rows > 0) {
        // Fetch the doctor's details
        $row = $result->fetch_assoc();
        $doctor_id = $row['doctor_id'];
        $doctor_name = $row['name'];

        // Log the login attempt into 'doctor_login' table
        $login_time = date("Y-m-d H:i:s");

        // Check if the doctor_logins table exists
        $check_table_sql = "SHOW TABLES LIKE 'doctor_login'";
        $check_result = $conn->query($check_table_sql);
        
        if ($check_result->num_rows > 0) {
            // Insert login record only if table exists
            $insert_sql = "INSERT INTO doctor_login (doctor_id, login_time, password) VALUES (?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("sss", $doctor_id, $login_time, $password);
            $insert_stmt->execute();
            $insert_stmt->close();
        } else {
            echo json_encode([
                'status' => 'false',
                'message' => "Error: 'doctor_logins' table does not exist. Please create it first.",
            ], JSON_PRETTY_PRINT);
            exit;
        }

        echo json_encode([
            'status' => 'true',
            'message' => 'Login successful',
            'doctor_id' => $doctor_id,
            'name' => $doctor_name,
            'login_time' => $login_time
        ], JSON_PRETTY_PRINT);
    } else {
        // No matching record found
        echo json_encode([
            'status' => 'false',
            'message' => 'Invalid doctor ID or password.',
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method
    echo json_encode([
        'status' => 'false',
        'message' => 'Invalid request method.',
    ], JSON_PRETTY_PRINT);
}
?>