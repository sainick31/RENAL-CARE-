ScrollView {
                    VStack(spacing: 25) {
                        FeatureCard(title: "Nutrition Calculator", icon: "chart.bar.fill", color: .pink, alignLeft: true)
                        FeatureCard(title: "Watch Awareness Videos", icon: "play.rectangle.fill", color: .purple, alignLeft: false)
                        FeatureCard(title: "Nutrition Table", icon: "book.fill", color: .orange, alignLeft: true)
                        FeatureCard(title: "Nutritional Deficiency", icon: "pills.fill", color: .green, alignLeft: false)
                    }
                    .padding(.horizontal)
                    .padding(.top, 20) // Adds spacing below header
                }
            }
        }
    }
}

struct FeatureCard: View {
    var title: String
    var icon: String
    var color: Color
    var alignLeft: Bool

    var body: some View {
        HStack {
            if alignLeft {
                FeatureIcon(icon: icon, color: color)
            }
            
            Text(title)
                .font(.title.bold()) // Increased text size
                .foregroundColor(.black)
                .padding()
            
            if !alignLeft {
                FeatureIcon(icon: icon, color: color)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 120) // Enlarged card height
        .background(Color.white.opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: 25))
        .shadow(radius: 5)
        .padding(.horizontal)
    }
}

struct FeatureIcon: View {
    var icon: String
    var color: Color
    
    var body: some View {
        Image(systemName: icon)
            .resizable()
            .frame(width: 70, height: 70) // Enlarged icon size
            .foregroundColor(.white)
            .padding()
            .background(color)
            .clipShape(Circle()) // Changed to circular shape for uniqueness
            .padding(.horizontal, 10)
    }
}