<?php
header("Content-Type: application/json");

// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "nutrition";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    echo json_encode(["status" => false, "message" => "Database connection failed"]);
    exit;
}

// Get user question from form-data
$question = strtolower($_POST["qns"] ?? "hello");

// Correct Ollama path
$ollama_path = "/opt/homebrew/bin/ollama";  // Update to your actual Ollama path

// AI Response Logic
$command = escapeshellcmd("$ollama_path run mistral \"$question\"");
$output = shell_exec($command);
$response = trim($output);

// Handle AI failure
if (!$response) {
    echo json_encode(["status" => false, "message" => "Ollama did not return a response."]);
    exit;
}

// Save Question & Response in MySQL
$stmt = $conn->prepare("INSERT INTO chat_history (user_question, ai_response) VALUES (?, ?)");
$stmt->bind_param("ss", $question, $response);
$stmt->execute();
$stmt->close();

// Return response in Postman format
echo json_encode([
    "status" => true,
    "data" => [
        ["answer" => $response]
    ]
]);

$conn->close();
?>

