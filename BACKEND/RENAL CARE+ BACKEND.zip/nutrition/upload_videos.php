<?php
// Enable error reporting for debugging (Disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '_con.php'; // Database connection file

header('Content-Type: application/json'); // Ensure JSON response

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Debugging: Log incoming raw POST data
    error_log('Raw POST data: ' . file_get_contents('php://input'));

    // Retrieve and sanitize inputs
    $video_title = isset($_POST['video_title']) ? trim($_POST['video_title']) : '';
    $video_url = isset($_POST['video_url']) ? trim($_POST['video_url']) : '';

    // Validate required fields
    if (empty($video_title) || empty($video_url)) {
        echo json_encode([
            'status' => false,
            'message' => 'Video title and URL are required.',
            'data' => []
        ]);
        exit;
    }

    // Validate YouTube URL format
    if (!filter_var($video_url, FILTER_VALIDATE_URL) || !preg_match('/^(https?\:\/\/)?(www\.youtube\.com|youtu\.be)/', $video_url)) {
        echo json_encode([
            'status' => false,
            'message' => 'Invalid YouTube URL.',
            'data' => []
        ]);
        exit;
    }

    // Generate a random 4-digit video ID
    $video_id = str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);

    // Prepare SQL statement
    $sql = "INSERT INTO upload_videos (video_id, title, youtube_url) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        // Log MySQL error for debugging
        error_log("SQL Prepare Error: " . $conn->error);
        echo json_encode([
            'status' => false,
            'message' => 'Database error: Failed to prepare statement.',
            'data' => []
        ]);
        exit;
    }

    // Bind parameters
    $stmt->bind_param("sss", $video_id, $video_title, $video_url);

    // Execute query
    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,
            'message' => 'Video added successfully.',
            'data' => [
                [
                    'video_id' => $video_id,
                    'title' => $video_title,
                    'youtube_url' => $video_url
                ]
            ]
        ]);
    } else {
        // Log MySQL execution error
        error_log("SQL Execution Error: " . $stmt->error);
        echo json_encode([
            'status' => false,
            'message' => 'Failed to add video.',
            'data' => []
        ]);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Use POST instead.',
        'data' => []
    ]);
}
?>