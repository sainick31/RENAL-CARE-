<?php
include '_con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize patient_id
    $patient_id = trim($_POST['patient_id']);

    // Validate if patient_id is provided
    if (empty($patient_id)) {
        echo json_encode([
            'status' => 'false',
            'message' => 'Patient ID is required.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Check if patient_id exists in the add_patient table
    $check_sql = "SELECT patient_id FROM add_patient WHERE patient_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    if (!$check_stmt) {
        echo json_encode([
            'status' => 'false',
            'message' => 'Database error: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }
    $check_stmt->bind_param("s", $patient_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        // Patient ID exists, collect and sanitize investigation details
        $hemoglobin = trim($_POST['hemoglobin']);
        $pcv = trim($_POST['pcv']);
        $total_wbc_count = trim($_POST['total_wbc_count']);
        $creatinine = trim($_POST['creatinine']);
        $potassium = trim($_POST['potassium']);
        $serum_cholesterol = trim($_POST['serum_cholesterol']);
        $serum_albumin = trim($_POST['serum_albumin']);
        $bicarbonate = trim($_POST['bicarbonate']);
        $ejection_fraction = trim($_POST['ejection_fraction']);

        // Check if any required fields are empty
        if (
            empty($hemoglobin) || empty($pcv) || empty($total_wbc_count) || empty($creatinine) ||
            empty($potassium) || empty($serum_cholesterol) || empty($serum_albumin) || empty($bicarbonate) || empty($ejection_fraction)
        ) {
            echo json_encode([
                'status' => 'false',
                'message' => 'All fields are required.'
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // Prepare the SQL statement to insert investigation details
        $sql = "INSERT INTO investigations 
                (patient_id, hemoglobin, pcv, total_wbc_count, creatinine, potassium, serum_cholesterol, serum_albumin, bicarbonate, ejection_fraction) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            echo json_encode([
                'status' => 'false',
                'message' => 'Database error: ' . $conn->error
            ], JSON_PRETTY_PRINT);
            exit;
        }

        $stmt->bind_param("ssssssssss", $patient_id, $hemoglobin, $pcv, $total_wbc_count, $creatinine, $potassium, $serum_cholesterol, $serum_albumin, $bicarbonate, $ejection_fraction);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode([
                'status' => 'true',
                'message' => 'Investigation data inserted successfully',
                'data' => [
                    [
                        'patient_id' => $patient_id,
                        'hemoglobin' => $hemoglobin,
                        'pcv' => $pcv,
                        'total_wbc_count' => $total_wbc_count,
                        'creatinine' => $creatinine,
                        'potassium' => $potassium,
                        'serum_cholesterol' => $serum_cholesterol,
                        'serum_albumin' => $serum_albumin,
                        'bicarbonate' => $bicarbonate,
                        'ejection_fraction' => $ejection_fraction
                    ]
                ]
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => 'false',
                'message' => 'Failed to add investigation data: ' . $stmt->error
            ], JSON_PRETTY_PRINT);
        }

        // Close the statement
        $stmt->close();
    } else {
        // If patient_id does not exist, return an error message
        echo json_encode([
            'status' => 'false',
            'message' => 'Invalid patient ID. No such patient exists.'
        ], JSON_PRETTY_PRINT);
    }

    // Close the check statement and connection
    $check_stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => 'false',
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
?>