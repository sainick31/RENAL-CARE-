<?php
include '_con.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize input data
    $food = trim($_POST['food']);
    $quantity = trim($_POST['quantity']);
    $carbohydrate = trim($_POST['carbohydrate']);
    $calorie = trim($_POST['calorie']);
    $protein = trim($_POST['protein']);
    $sodium = trim($_POST['sodium']);
    $potassium = trim($_POST['potassium']);

    // Validate required fields
    if (empty($food) || empty($quantity) || empty($carbohydrate) || empty($calorie) || empty($protein) || empty($sodium) || empty($potassium)) {
        echo json_encode([
            'status' => 'false',
            'message' => 'All fields are required.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare SQL statement to insert data
    $sql = "INSERT INTO food_items (food, quantity, carbohydrate, calorie, protein, sodium, potassium) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode([
            'status' => 'false',
            'message' => 'Database error: ' . $conn->error
        ], JSON_PRETTY_PRINT);
        exit;
    }

    $stmt->bind_param("sssssss", $food, $quantity, $carbohydrate, $calorie, $protein, $sodium, $potassium);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode([
            'status' => 'true',
            'message' => 'Food item added successfully',
            'data' => [
                [
                    'food' => $food,
                    'quantity' => $quantity,
                    'carbohydrate' => $carbohydrate,
                    'calorie' => $calorie,
                    'protein' => $protein,
                    'sodium' => $sodium,
                    'potassium' => $potassium
                ]
            ]
        ], JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'status' => 'false',
            'message' => 'Failed to add food item: ' . $stmt->error
        ], JSON_PRETTY_PRINT);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode([
        'status' => 'false',
        'message' => 'Invalid request method.'
    ], JSON_PRETTY_PRINT);
}
?>