<?php
include '_con.php'; // Database connection

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve input from POST request
    $patient_id = isset($_POST['patient_id']) ? trim($_POST['patient_id']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validate input
    if (empty($patient_id) || empty($password)) {
        echo json_encode([
            'status' => 'false',
            'message' => 'Patient ID and password are required.'
        ], JSON_PRETTY_PRINT);
        exit;
    }

    // Prepare SQL to fetch patient details (only existing columns)
    $sql = "SELECT patient_id, password FROM add_patient WHERE BINARY patient_id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die(json_encode([
            'status' => 'false',
            'message' => 'Database error: ' . $conn->error
        ], JSON_PRETTY_PRINT));
    }

    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if patient exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];

        // Verify password
        if (password_verify($password, $hashed_password) || $password === $hashed_password) {
            // Insert login attempt into patient_login table
            $insert_sql = "INSERT INTO patient_login (patient_id, login_time) VALUES (?, NOW())";
            $insert_stmt = $conn->prepare($insert_sql);

            if (!$insert_stmt) {
                die(json_encode([
                    'status' => 'false',
                    'message' => 'Database error (INSERT failed): ' . $conn->error
                ], JSON_PRETTY_PRINT));
            }

            $insert_stmt->bind_param("s", $patient_id);
            $insert_stmt->execute();
            $insert_stmt->close();

            // Return only patient_id in the data array
            echo json_encode([
                'status' => 'true',
                'message' => 'Login successful',
                'data' => [
                    [
                        'patient_id' => $row['patient_id'],
                        'log_status' => 'Login recorded successfully'
                    ]
                ]
            ], JSON_PRETTY_PRINT);
        } else {
            echo json_encode([
                'status' => 'false',
                'message' => 'Invalid password.'
            ], JSON_PRETTY_PRINT);
        }
    } else {
        echo json_encode([
            'status' => 'false',
            'message' => 'Invalid patient ID. Patient might not exist in the database.'
        ], JSON_PRETTY_PRINT);
    }

    // Close resources
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method
    echo json_encode([
        'status' => 'false',
        'message' => 'Invalid request method. Use POST.'
    ], JSON_PRETTY_PRINT);
}
?>
