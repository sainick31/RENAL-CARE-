import SwiftUI

struct PatientProfile: View {
    @Environment(\.presentationMode) var presentationMode // ✅ Enables navigation back

    var body: some View {
        NavigationView {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.cyan.opacity(0.4)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 24) {
                    // Header with Back Button and Profile Emoji
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .fill(Color.blue.opacity(0.8))
                            .frame(height: 200)

                        HStack {
                            // Back Button (Navigates back to `patient_menu`)
                            Button(action: {
                                presentationMode.wrappedValue.dismiss() // ✅ Goes back to `patient_menu`
                            }) {
                                Image(systemName: "chevron.left.circle.fill")
                                    .font(.largeTitle)
                                    .foregroundColor(.white)
                                    .shadow(radius: 5)
                            }
                            .padding(.leading, 10)
                            .padding(.top, 25)

                            Spacer()

                            // Profile Header
                            HStack {
                                Text("👤") // Profile emoji
                                    .font(.system(size: 32))

                                Text("Profile")
                                    .font(.custom("Doppio One", size: 32))
                                    .foregroundColor(.white)
                            }
                            .padding(.top, 45)

                            Spacer()
                        }
                        .padding(.horizontal, 20)
                    }
                    .padding(.top, -70)

                    // Scrollable Profile Information List
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 12) {
                            ProfileInfoRow(label: "Name", value: "XXXXXXX")
                            ProfileInfoRow(label: "Age", value: "21")
                            ProfileInfoRow(label: "Gender", value: "Male")
                            ProfileInfoRow(label: "User ID", value: "192111")
                            ProfileInfoRow(label: "Height", value: "1.75 m")
                            ProfileInfoRow(label: "Weight", value: "47 kgs")
                            ProfileInfoRow(label: "BMI", value: "15.3")
                            ProfileInfoRow(label: "Joined Date", value: "2019")
                            ProfileInfoRow(label: "Experience", value: "5 years")
                            ProfileInfoRow(label: "Diet Preference", value: "Vegetarian")
                            ProfileInfoRow(label: "Mobile Number", value: "9550638946")
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 5)
                        .padding(.bottom, 30)
                    }
                }
                .padding(.top, 5)
            }
            .navigationBarBackButtonHidden(true) // ✅ Hides default back button
        }
    }
}

// Custom Row for Profile Information
struct ProfileInfoRow: View {
    var label: String
    var value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.custom("Doppio One", size: 18))
                .foregroundColor(.white)
                .frame(width: 160, height: 45)
                .background(Color.blue.opacity(0.85))
                .cornerRadius(22)

            Spacer()

            Text(value)
                .font(.custom("Doppio One", size: 18))
                .foregroundColor(.black)
                .frame(width: 160, height: 45)
                .background(Color.white)
                .cornerRadius(22)
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .stroke(Color.black.opacity(0.5), lineWidth: 1)
                )
        }
        .padding(.horizontal, 10)
    }
}

// Preview
struct PatientProfile_Previews: PreviewProvider {
    static var previews: some View {
        PatientProfile()
    }
}
