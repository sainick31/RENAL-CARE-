import SwiftUI

struct UploadVideos: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var videoTitle: String = ""
    @State private var videoURL: String = ""
    @State private var isUploading: Bool = false
    @State private var uploadMessage: String?

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.7), Color.purple.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)

                VStack {
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 35, height: 35)
                                .foregroundColor(.white)
                                .shadow(radius: 5)
                        }
                        .padding(.leading, 20)

                        Spacer()
                    }
                    .frame(height: 60)

                    Text("Upload Videos")
                        .font(.custom("Doppio One", size: 28))
                        .foregroundColor(.white)
                        .padding(.top, 20)
                        .shadow(radius: 5)

                    VStack(spacing: 10) {
                        TextField("Title", text: $videoTitle)
                            .font(.custom("Inter", size: 16).weight(.semibold))
                            .padding()
                            .frame(height: 50)
                            .background(Color.white.opacity(0.9))
                            .cornerRadius(13)
                            .shadow(radius: 2)

                        HStack {
                            TextField("Enter Video URL", text: $videoURL)
                                .font(.custom("Inter", size: 16).weight(.semibold))
                                .padding()
                                .background(Color.white.opacity(0.9))
                                .cornerRadius(13)
                                .shadow(radius: 2)

                            Button(action: {
                                uploadVideo(title: videoTitle, url: videoURL)
                            }) {
                                Image(systemName: "arrow.up.circle.fill")
                                    .resizable()
                                    .frame(width: 35, height: 35)
                                    .foregroundColor(.green)
                            }
                        }
                        .frame(height: 50)

                        if let message = uploadMessage {
                            Text(message)
                                .foregroundColor(.white)
                                .font(.footnote)
                                .padding(.top, 5)
                        }
                    }
                    .padding(.horizontal, 35)
                    .padding(.top, 10)

                    Text("Uploaded Videos")
                        .font(.custom("Doppio One", size: 22))
                        .foregroundColor(.red)
                        .padding(.top, 20)

                    ScrollView {
                        VStack(spacing: 20) {
                            UploadedVideoCard(imageName: "video1", title: "Basic Nutrients")
                            UploadedVideoCard(imageName: "video2", title: "The Role of Food in Health")
                            UploadedVideoCard(imageName: "video3", title: "Fit Facts | Food and Nutrition")
                            UploadedVideoCard(imageName: "video4", title: "A Healthier Diet | Better World")
                            UploadedVideoCard(imageName: "video5", title: "Eating Healthy")
                            UploadedVideoCard(imageName: "video6", title: "Satvik Food")
                        }
                        .padding(.bottom, 30)
                    }
                    .frame(height: 450)
                    .padding(.horizontal, 15)

                    Spacer()
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }

    // MARK: - Upload Function
    func uploadVideo(title: String, url: String) {
        guard let uploadURL = URL(string: "http://localhost/nutrition/upload_videos.php") else {
            uploadMessage = "Invalid URL"
            return
        }

        var request = URLRequest(url: uploadURL)
        request.httpMethod = "POST"

        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        let formFields = [
            "video_id": "",
            "video_title": title,
            "video_url": url,
            "status": ""
        ]

        for (key, value) in formFields {
            body.append("--\(boundary)\r\n")
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
            body.append("\(value)\r\n")
        }

        body.append("--\(boundary)--\r\n")
        request.httpBody = body

        isUploading = true
        uploadMessage = "Uploading..."

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                isUploading = false
                if let error = error {
                    uploadMessage = "Upload failed: \(error.localizedDescription)"
                    return
                }

                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    uploadMessage = "Server error"
                    return
                }

                uploadMessage = "Video uploaded successfully!"
                videoTitle = ""
                videoURL = ""
            }
        }.resume()
    }
}

// MARK: - Uploaded Video Card
struct UploadedVideoCard: View {
    var imageName: String
    var title: String

    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack {
                ZStack {
                    Image(imageName)
                        .resizable()
                        .frame(width: 340, height: 180)
                        .cornerRadius(12)
                        .overlay(
                            Image(systemName: "play.circle.fill")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.white)
                                .shadow(radius: 5)
                                .opacity(0.8)
                        )
                }
                .frame(width: 340, height: 180)
                .cornerRadius(15)
                .shadow(radius: 5)

                Text(title)
                    .font(.custom("Doppio One", size: 18))
                    .foregroundColor(.black)
                    .padding(.top, 5)
            }
            .frame(width: 350)
            .background(Color.white)
            .cornerRadius(15)
            .shadow(radius: 5)
            .scaleEffect(1.0)
            .onTapGesture {
                print("\(title) tapped")
            }

            Button(action: {
                print("\(title) removed")
            }) {
                Image(systemName: "xmark.circle.fill")
                    .resizable()
                    .frame(width: 25, height: 25)
                    .foregroundColor(.red)
                    .background(Color.white)
                    .clipShape(Circle())
                    .shadow(radius: 5)
            }
            .offset(x: -10, y: 10)
        }
    }
}

// MARK: - Data Extension for Multipart Form
extension Data {
    mutating func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}

// MARK: - Preview
struct UploadVideosPreviews: PreviewProvider {
    static var previews: some View {
        UploadVideos()
    }
}
