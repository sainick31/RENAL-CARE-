import SwiftUI

struct PatientChangePassword: View {
    @Environment(\.presentationMode) var presentationMode // ✅ Enables navigation back
    @State private var username: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var navigateToPatientHome = false // ✅ For manual navigation
    
    var body: some View {
        NavigationView { // ✅ Wrap in NavigationView
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.cyan.opacity(0.6)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    // Back Button (Navigates back to `patient_menu`)
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss() // ✅ Goes back to `patient_menu`
                        }) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)
                                .padding(.leading, 20)
                        }
                        Spacer()
                    }
                    .padding(.top, 20)
                    
                    Spacer()
                    
                    VStack(spacing: 15) {
                        // Header
                        Text("Change Password")
                            .font(.system(size: 36, weight: .bold))
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.5), radius: 4, x: 0, y: 3)
                            .padding(.bottom, 10)
                        
                        // Input Fields
                        CustomTextField(icon: "person.fill", placeholder: "Enter Username", text: $username)
                        CustomSecureField(icon: "lock.fill", placeholder: "Enter New Password", text: $newPassword)
                        CustomSecureField(icon: "lock.fill", placeholder: "Re-enter Password", text: $confirmPassword)
                    }
                    .padding(.bottom, 10)
                    
                    // Navigation to `patient_home`
                    NavigationLink(destination: PatientHome(), isActive: $navigateToPatientHome) {
                        EmptyView()
                    }
                    .hidden()
                    
                    // Reset Button
                    Button(action: {
                        print("Password Reset Attempted")
                        navigateToPatientHome = true // ✅ Navigate manually
                    }) {
                        Text("Reset Password")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.9), Color.pink.opacity(0.7)]),
                                                       startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(15)
                            .shadow(color: .black.opacity(0.4), radius: 5, x: 0, y: 3)
                            .padding(.horizontal, 40)
                    }
                    .padding(.top, 5)
                    
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.horizontal, 20)
            }
            .navigationBarBackButtonHidden(true) // ✅ Hides default back button
        }
    }
}

// Preview
struct PatientChangePassword_Previews: PreviewProvider {
    static var previews: some View {
        PatientChangePassword()
    }
}
