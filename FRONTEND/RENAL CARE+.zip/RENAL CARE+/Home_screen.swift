import SwiftUI

struct HomeScreen: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Gradient Background
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.7)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: -30) {
                    // App Logo & Title
                    VStack {
                        Image("logo") // Customizable Logo
                            .resizable()
                            .scaledToFit()
                            .frame(width: 130, height: 130)
                            .foregroundColor(.white)
                            .shadow(radius: 15)
                        
                        Text("Renal Care+")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .shadow(radius: 5)
    
                    }
                    .padding(.top, 80)
                    
                    Spacer()
                    
                    // Profile Images & Buttons (Only Accessible Elements)
                    VStack(spacing: 40) {
                        VStack {
                            // Doctor Image (Not Clickable)
                            Image("doctor") // Local image asset
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.white, lineWidth: 3))
                                .shadow(radius: 5)
                            
                            // Doctor Button (Only Clickable Element)
                            NavigationLink(destination: DoctorLogin().navigationBarBackButtonHidden(true)) {
                                UserButton(title: "DOCTOR", icon: "stethoscope", color: Color.blue)
                            }
                        }
                        
                        VStack {
                            // Patient Image (Not Clickable)
                            Image("patient") // Local image asset
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.white, lineWidth: 3))
                                .shadow(radius: 5)
                            
                            // Patient Button (Back button removed)
                            NavigationLink(destination: PatientLogin().navigationBarBackButtonHidden(true)) {
                                UserButton(title: "PATIENT", icon: "heart.fill", color: Color.pink)
                            }
                        }
                    }
                    
                    Spacer()
                }
                .padding()
            }
        }
    }
}

// Custom View for User Buttons
struct UserButton: View {
    var title: String
    var icon: String
    var color: Color
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .resizable()
                .scaledToFit()
                .frame(width: 25, height: 25)
                .foregroundColor(.white)
            
            Text(title)
                .font(.headline)
                .foregroundColor(.white)
                .padding(.leading, 10)
        }
        .padding()
        .frame(width: 220, height: 60)
        .background(color.gradient)
        .cornerRadius(30)
        .shadow(radius: 5)
    }
}

// Preview
#Preview {
    HomeScreen()
}
