import SwiftUI

struct PatientDetails: View {
    @Environment(\.presentationMode) var presentationMode // For back navigation

    var body: some View {
        ZStack {
            // Gradient Background
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.2)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 33) {
                // Custom Header with Back and Edit Buttons
                VStack {
                    HStack {
                        // Back Button
                        Button(action: {
                            presentationMode.wrappedValue.dismiss() // Navigate back
                        }) {
                            HStack {
                                Image(systemName: "chevron.left.circle.fill")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .foregroundColor(.white)
                                    .shadow(radius: 5)
                            }
                        }
                        .padding(.leading, -5)

                        Spacer()

                        // Edit Button
                        Button(action: {
                            // Edit action
                        }) {
                            HStack {
                                Image(systemName: "pencil.circle.fill")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(.white)

                                Text("Edit")
                                    .font(.custom("Doppio One", size: 20))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 5)
                                    .background(Color.purple.opacity(0.6))
                                    .cornerRadius(15)
                            }
                        }
                        .padding(.trailing, -5)
                    }
                    .frame(height: 100)
                    .padding(.horizontal, 20)

                    // Centered Patient Details Heading
                    HStack {
                        Text("🧑‍⚕️") // Patient emoji
                            .font(.system(size: 30))

                        Text("Patient Details")
                            .font(.custom("Doppio One", size: 30))
                            .foregroundColor(.white)
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 5)
                }
                .frame(height: 200)
                .padding(.horizontal, 20)
                .background(Color.blue.opacity(0.8))
                .clipShape(RoundedRectangle(cornerRadius: 25))
                .padding(.top, -67)

                // Scrollable Patient Information List
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 15) {
                        PatientInfoRow(label: "Name", value: "XXXXXXX")
                        PatientInfoRow(label: "Age", value: "21")
                        PatientInfoRow(label: "Gender", value: "Male")
                        PatientInfoRow(label: "Patient ID", value: "192111")
                        PatientInfoRow(label: "Height", value: "1.75 m")
                        PatientInfoRow(label: "Dry Weight", value: "47 kgs")
                        PatientInfoRow(label: "BMI", value: "15.3")
                        PatientInfoRow(label: "Date of Initiation", value: "2019")
                        PatientInfoRow(label: "Dialysis Vintage", value: "5")
                        PatientInfoRow(label: "Type of Food Consumed", value: "Vegetarian")
                        PatientInfoRow(label: "Mobile Number", value: "9550638946")
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 5)
                    .padding(.bottom, 30)
                }
            }
            .padding(.top, 5)
        }
        .navigationBarBackButtonHidden(true) // Hide default back button
    }
}

// Custom Row for Patient Information
struct PatientInfoRow: View {
    var label: String
    var value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.custom("Doppio One", size: 18))
                .foregroundColor(.white)
                .frame(width: 160, height: 45)
                .background(Color.blue.opacity(0.85))
                .cornerRadius(22)

            Spacer()

            Text(value)
                .font(.custom("Doppio One", size: 18))
                .foregroundColor(.black)
                .frame(width: 160, height: 45)
                .background(Color.white)
                .cornerRadius(22)
                .overlay(
                    RoundedRectangle(cornerRadius: 22)
                        .stroke(Color.black.opacity(0.5), lineWidth: 1)
                )
        }
        .padding(.horizontal, 10)
    }
}

// Preview
struct PatientDetails_Previews: PreviewProvider {
    static var previews: some View {
        PatientDetails()
    }
}
