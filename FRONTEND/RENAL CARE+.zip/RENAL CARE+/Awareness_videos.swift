import SwiftUI

struct AwarenessVideos: View {
    let videos = [
        ("Basic Nutrients", "video_thumbnail_1"),
        ("The Role of Food in Health", "video_thumbnail_2"),
        ("Fit Facts | Food and Nutrition", "video_thumbnail_3"),
        ("A Healthier Diet | Better World", "video_thumbnail_4"),
        ("Eating Healthy", "video_thumbnail_5"),
        ("Satvik Food", "video_thumbnail_6")
    ]
    
    @State private var navigateToPatientHome = false // Navigation state

    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.cyan.opacity(0.4)]),
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    // Back Button (Top Left)
                    HStack {
                        Button(action: {
                            print("Navigating to patient_home") // Debugging
                            navigateToPatientHome = true
                        }) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 35, height: 35)
                                .foregroundColor(.white)
                                .shadow(radius: 3)
                        }
                        .padding(.leading, 20)
                        
                        Spacer()
                    }
                    .frame(height: 45) // Adjusted height
                    
                    // Centered Header
                    Text("📹 Awareness Videos")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .padding(.vertical, 10)
                        .frame(maxWidth: UIScreen.main.bounds.width * 0.8)
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.blue.opacity(0.8)]),
                                                     startPoint: .leading, endPoint: .trailing))
                                .shadow(radius: 5)
                        )
                        .padding(.bottom, 10)
                    
                    // Video List
                    ScrollView {
                        VStack(spacing: 20) {
                            ForEach(videos, id: \.0) { video in
                                VideoCard(title: video.0)
                            }
                        }
                        .padding()
                    }
                }
                .padding(.top, 15)
            }
            .navigationDestination(isPresented: $navigateToPatientHome) {
                PatientHome()
                    .navigationBarBackButtonHidden(true)
                    .onAppear {
                        print("Successfully Navigated to patient_home") // Debugging
                    }
            }
        }
    }
}

// Video Card Component
struct VideoCard: View {
    let title: String
    
    var body: some View {
        VStack {
            ZStack(alignment: .topTrailing) {
                // Card Background
                RoundedRectangle(cornerRadius: 15)
                    .fill(Color.white)
                    .shadow(radius: 5)
                    .frame(height: 180)
                
                // Play Button
                Button(action: {
                    print("Play \(title)")
                }) {
                    Image(systemName: "play.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .foregroundColor(.gray.opacity(0.8))
                }
                .position(x: UIScreen.main.bounds.width / 2 - 40, y: 90)
                
                // Close Button
                Button(action: {
                    print("Close \(title)")
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 27, height: 27)
                        .foregroundColor(.red)
                        .background(Circle().fill(Color.white))
                        .shadow(radius: 2)
                }
                .padding(12)
            }
            .padding(.horizontal)
            
            // Title Below Card
            Text(title)
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.black)
                .padding(.top, 5)
        }
    }
}

// Preview
struct AwarenessVideos_Previews: PreviewProvider {
    static var previews: some View {
        AwarenessVideos()
    }
}
