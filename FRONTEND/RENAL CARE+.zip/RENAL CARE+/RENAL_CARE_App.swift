//
//  RENAL_CARE_App.swift
//  RENAL CARE+
//
//  Created by SAIL on 19/03/25.
//

import SwiftUI

@main
struct RENAL_CARE_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
