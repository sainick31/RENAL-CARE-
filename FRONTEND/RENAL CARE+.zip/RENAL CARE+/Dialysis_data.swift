import SwiftUI

struct DialysisData: View {
    @Environment(\.presentationMode) var presentationMode // Handle back navigation
    
    @State private var selectedDate = Date()
    @State private var weight = ""
    @State private var weightGain = ""
    @State private var preBP = ""
    @State private var postBP = ""
    @State private var urineOutput = ""
    @State private var tricepSkinfold = 0.0
    @State private var handGripStrength = 0.0
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)
                
                
                    VStack(spacing: 25) {
                        HStack {
                            // Back Button
                            Button(action: {
                                presentationMode.wrappedValue.dismiss() // Navigate back
                            }) {
                                Image(systemName: "chevron.left.circle.fill")
                                    .font(.system(size: 40, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            Spacer()
                        }
                        .padding(.horizontal)
                        
                        // Header
                        Text("Dialysis Data")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(20)
                            .padding(.horizontal)
                        
                        ScrollView {
                        VStack(spacing: 15) {
                            DatePickerField(title: "Date", selectedDate: $selectedDate)
                            InputField(title: "Weight", text: $weight, icon: "scalemass")
                            InputField(title: "Weight Gain", text: $weightGain, icon: "person.fill")
                            InputField(title: "Pre - BP", text: $preBP, icon: "heart.fill")
                            InputField(title: "Post - BP", text: $postBP, icon: "heart.fill")
                        }
                        .padding(.horizontal)
                        
                        VStack(alignment: .leading) {
                            Text("Urine Output")
                                .font(.system(size: 20, weight: .semibold))
                            HStack {
                                TextField("Enter value", text: $urineOutput)
                                    .keyboardType(.numberPad)
                                    .padding()
                                    .frame(width: 100, height: 40)
                                    .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 2))
                                    .multilineTextAlignment(.center)
                                Text("ml")
                                    .font(.system(size: 20, weight: .semibold))
                            }
                        }
                        .padding(.horizontal)
                        
                        Button(action: {}) {
                            Text("Nutritional Assessment Tools")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(RoundedRectangle(cornerRadius: 15).fill(Color.green))
                        }
                        .padding(.horizontal)
                        
                        VStack(alignment: .leading, spacing: 15) {
                            CustomStepper(title: "Tricep Skinfold Thickness", value: $tricepSkinfold, unit: "mm")
                            CustomStepper(title: "Hand Grip Strength", value: $handGripStrength, unit: "kg")
                        }
                        .padding(.horizontal)
                        
                        // Investigations as Button
                        NavigationLink(destination: Investigations()) {
                            Text("Investigations")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(RoundedRectangle(cornerRadius: 15).fill(Color.blue))
                        }
                        .padding()
                    }
                }
                    .navigationBarBackButtonHidden(true)
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct DatePickerField: View {
    let title: String
    @Binding var selectedDate: Date
    
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 18, weight: .semibold))
            Spacer()
            DatePicker("", selection: $selectedDate, displayedComponents: .date)
                .labelsHidden()
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 2))
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.white).shadow(radius: 2))
    }
}

struct InputField: View {
    let title: String
    @Binding var text: String
    let icon: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 18, weight: .semibold))
            Spacer()
            TextField("Enter \(title.lowercased())", text: $text)
                .padding()
                .frame(width: 150, height: 40)
                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 2))
                .multilineTextAlignment(.trailing)
            Image(systemName: icon)
                .foregroundColor(.gray)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.white).shadow(radius: 2))
    }
}

struct CustomStepper: View {
    let title: String
    @Binding var value: Double
    let unit: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 18, weight: .semibold))
            Spacer()
            Button(action: { value -= 0.5 }) {
                Image(systemName: "minus.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(.red)
            }
            Text("\(String(format: "%.1f", value)) \(unit)")
                .frame(width: 80)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
                .padding(.horizontal, 5)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).shadow(radius: 2))
            Button(action: { value += 0.5 }) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(.green)
            }
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.white).shadow(radius: 2))
    }
}

struct DialysisData_Previews: PreviewProvider {
    static var previews: some View {
        DialysisData()
    }
}
