import SwiftUI

struct PatientMonitoring: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.2)]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 50) {
                    // Beautified Header
                    VStack {
                        Text("📌 Patient Dashboard")
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 4)
                            .padding(.top, 60)
                        
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white.opacity(0.2))
                            .frame(width: 220, height: 5)
                            .padding(.top, -10)
                    }
                    .frame(maxWidth: .infinity, minHeight: 140)
                    .background(
                        LinearGradient(gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.6)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .cornerRadius(20)
                    .shadow(radius: 30)
                    
                    // Main Content Grid
                    LazyVGrid(columns: [GridItem(.flexible())], spacing: 20) {
                        // Navigation Links
                        NavigationLink(destination: PatientDetails()) {
                            DashboardCard(title: "Patient Details", icon: "person.fill", color: Color.pink)
                        }
                        
                        NavigationLink(destination: CaseSheet()) {
                            DashboardCard(title: "Case Sheet", icon: "doc.text.fill", color: Color.green)
                        }
                        
                        NavigationLink(destination: PatientRecords()) {
                            DashboardCard(title: "Patient Records", icon: "folder.fill", color: Color.orange)
                        }
                        
                        NavigationLink(destination: NutritionTableView()) {
                            DashboardCard(title: "Nutrition Table", icon: "leaf.fill", color: Color.purple)
                        }
                    }
                    .padding(.top, -20)
                    
                    Spacer()
                }
            }
        }
    }
}

// Reusable Dashboard Card Component
struct DashboardCard: View {
    var title: String
    var icon: String
    var color: Color
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .resizable()
                .scaledToFit()
                .frame(width: 70, height: 70)
                .foregroundColor(.white)
            Text(title)
                .font(.title2)
                .foregroundColor(.white)
                .padding(.top, 10)
        }
        .frame(width: 350, height: 150)
        .background(color.opacity(0.9))
        .cornerRadius(20)
        .shadow(radius: 5)
    }
}

// Preview
struct PatientMonitoring_Previews: PreviewProvider {
    static var previews: some View {
        PatientMonitoring()
    }
}
