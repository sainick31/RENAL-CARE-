import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Gradient Background
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.7)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 20) {
                    // Circular Image with shadow
                    Image("logo") // Replace with actual asset name
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                    
                    // App Title
                    Text("Renal Care+")
                        .font(.custom("Avenir-Black", size: 42))
                        .foregroundColor(Color.white)
                        .bold()
                    
                    // Subtitle
                    Text("Supporting your health with\n every bite")
                        .font(.system(size: 18))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                    
                    // Navigation to ContentView
                    NavigationLink(destination: HomeScreen().navigationBarBackButtonHidden(true)) {
                        Text("GET STARTED")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)
                            .frame(width: 200, height: 50)
                            .background(Color.white.opacity(0.9))
                            .cornerRadius(25)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.black, lineWidth: 1))
                            .navigationBarHidden(true)
                    }
                    .padding(.top, 10)
                }
                .padding()
            }
            .navigationBarHidden(true) // Hide navigation bar on home screen
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
