import SwiftUI

struct CaseSheet: View {
    @Environment(\.presentationMode) var presentationMode
    
    @State private var conditions: [String: Bool] = [
        "T2DM (Type 2 Diabetes Mellitus)": false,
        "HTN (Hypertension)": false,
        "CVA (Cerebrovascular Disease)": false,
        "CVD (Cardiovascular Disease)": false,
        "Others": false
    ]
    
    @State private var accessSites: [String: [String: Bool]] = [
        "CVC (Central Venous Catheter)": [
            "Left IJV": false,
            "Right IJV": false
        ],
        "Femoral": [
            "Left Femoral": false,
            "Right Femoral": false
        ],
        "AVF (Arteriovenous Fistula)": [
            "Left Radiocephalic Fistula": false,
            "Right Radiocephalic Fistula": false,
            "Left Brachiocephalic Fistula": false,
            "Right Brachiocephalic Fistula": false
        ],
        "AVG (Arterio Venous Graft)": [
            "Left AVG": false,
            "Right AVG": false
        ]
    ]
    
    @State private var description: String = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.4)]),
                    startPoint: .top, endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack {
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image(systemName: "chevron.left.circle.fill")
                                .font(.title)
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                        }
                        .padding(.leading)
                        
                        Text("🩺 Patient Data")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 20)
                        
                        Spacer()
                    }
                    .frame(height: 80)
                    .background(Color.blue.opacity(0.8))
                    
                    ScrollView {
                        VStack(alignment: .leading, spacing: 20) {
                            CustomCard(title: "Comorbidities", items: $conditions)
                            
                            VStack(alignment: .leading) {
                                Text("Description")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.blue)
                                
                                TextField("Enter description here...", text: $description)
                                    .padding()
                                    .background(Color.white.opacity(0.9))
                                    .cornerRadius(10)
                                    .shadow(radius: 3)
                            }
                            .padding(.horizontal)
                            
                            Button(action: {}) {
                                Text("Access")
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(maxWidth: 200)
                                    .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.teal]), startPoint: .leading, endPoint: .trailing))
                                    .cornerRadius(25)
                                    .shadow(radius: 5)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            
                            ForEach(accessSites.keys.sorted(), id: \.self) { category in
                                VStack(alignment: .leading) {
                                    Text(category)
                                        .font(.title2)
                                        .fontWeight(.bold)
                                        .foregroundColor(.blue)
                                    
                                    VStack {
                                        ForEach(accessSites[category]!.keys.sorted(), id: \.self) { key in
                                            Toggle(key, isOn: Binding(
                                                get: { self.accessSites[category]![key] ?? false },
                                                set: { self.accessSites[category]![key] = $0 }
                                            ))
                                            .toggleStyle(CheckboxToggleStyle())
                                        }
                                    }
                                    .padding()
                                    .background(Color.white.opacity(0.9))
                                    .cornerRadius(10)
                                    .shadow(radius: 3)
                                }
                                .padding(.horizontal)
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    Spacer()
                    
                    NavigationLink(destination: ScheduleFrequency()) {
                        Text("Schedule Frequency")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: 250)
                            .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.cyan]), startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(25)
                            .shadow(radius: 5)
                    }
                    .padding(.bottom, 20)

                }
            }
        }
        .navigationBarHidden(true)
    }
}

// Custom Card Component
struct CustomCard: View {
    var title: String
    @Binding var items: [String: Bool]
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.blue)
            
            VStack {
                ForEach(items.keys.sorted(), id: \.self) { key in
                    Toggle(key, isOn: Binding(
                        get: { self.items[key] ?? false },
                        set: { self.items[key] = $0 }
                    ))
                    .toggleStyle(CheckboxToggleStyle())
                }
            }
            .padding()
            .background(Color.white.opacity(0.9))
            .cornerRadius(10)
            .shadow(radius: 3)
        }
        .padding(.horizontal)
    }
}

// Custom Checkbox Toggle
struct CheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            configuration.label
                .font(.body)
            Spacer()
            Image(systemName: configuration.isOn ? "checkmark.square.fill" : "square")
                .resizable()
                .frame(width: 25, height: 25)
                .foregroundColor(.blue)
                .onTapGesture {
                    configuration.isOn.toggle()
                }
        }
        .padding(.vertical, 5)
    }
}

struct CaseSheet_Previews: PreviewProvider {
    static var previews: some View {
        CaseSheet()
    }
}
