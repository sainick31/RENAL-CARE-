import SwiftUI

struct NutritionDeficiency: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.cyan.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)

                VStack(spacing: 0) {
                    VStack {
                        HStack {
                            Button(action: {
                                dismiss() // Pop back to previous screen
                            }) {
                                Image(systemName: "chevron.left.circle.fill")
                                    .font(.largeTitle)
                                    .foregroundColor(.white)
                                    .padding()
                            }
                            Spacer()
                        }
                        .padding(.top, 30)

                        Text("🥦 Nutrition Deficiencies")
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(RoundedRectangle(cornerRadius: 25).fill(Color.pink.opacity(0.9)))
                            .shadow(radius: 5)
                            .padding(.horizontal, 30)
                            .padding(.bottom, 20)
                    }

                    ScrollView {
                        VStack(spacing: 25) {
                            Spacer().frame(height: 10)

                            NutrientHeaderView(title: "🔥 Calorie", value: "395 Kcal/Kg")

                            SuggestedFoodSection(foods: [
                                ("🥣 Oats Bowl", "1 cup", "407 Kcal"),
                                ("🍗 Chicken (Roasted, Cooked)", "100 g", "454 Kcal"),
                                ("🥕 Carrot Salad", "1 cup", "416 Kcal"),
                                ("🌾 Oats", "100 g", "389 Kcal"),
                                ("🌯 Wrap filled with vegetables", "1 wrap", "459 Kcal")
                            ])

                            NutrientHeaderView(title: "💪 Protein", value: "18.49 g/Kg")

                            SuggestedFoodSection(foods: [
                                ("🐟 Grilled Salmon with Broccoli", "1 cup", "22 g"),
                                ("🍣 Tuna Sashimi", "100 g", "21 g"),
                                ("🥣 Oatmeal with Blueberries", "1 cup", "22.5 g"),
                                ("🐠 Bluefin Tuna (Cooked, Dry Heat)", "100 g", "29.1 g"),
                                ("🍎 Cottage Cheese with Apples and Cinnamon", "1 wrap", "20 g")
                            ])
                        }
                        .padding(.top, 10)
                        .padding(.bottom, 50)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}

// MARK: - Supporting Views

struct NutrientHeaderView: View {
    var title: String
    var value: String

    var body: some View {
        HStack {
            Text("\(title)  :  \(value)")
                .font(.title2)
                .bold()
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(RoundedRectangle(cornerRadius: 15).fill(Color.green.opacity(0.8)))
                .shadow(radius: 5)
        }
        .padding(.horizontal, 20)
        .padding(.top, 5)
    }
}

struct SuggestedFoodSection: View {
    var foods: [(name: String, quantity: String, value: String)]

    var body: some View {
        VStack(alignment: .leading) {
            Text("🍽️ Suggested Food")
                .font(.title2)
                .bold()
                .foregroundColor(.red)
                .padding(.leading, 25)

            VStack(spacing: 15) {
                ForEach(foods, id: \.name) { food in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(food.name)
                            .font(.title3)
                            .bold()
                            .foregroundColor(.black)
                        Text(food.quantity)
                            .font(.body)
                            .foregroundColor(.gray)
                        Text("⭐ \(food.value)")
                            .font(.title3)
                            .foregroundColor(.blue)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 15).fill(Color.white))
                    .shadow(radius: 5)
                    .padding(.horizontal, 25)
                }
            }
            .padding(.bottom, 10)
        }
    }
}

// MARK: - Preview
struct NutritionDeficiency_Previews: PreviewProvider {
    static var previews: some View {
        NutritionDeficiency()
    }
}
