import SwiftUI

class PatientViewModel: ObservableObject {
    @Published var patients: [PatientModel] = []

    func addPatient(_ patient: PatientModel) {
        patients.append(patient)
    }
}
