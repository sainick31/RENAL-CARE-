import SwiftUI

struct DoctorChangePassword: View {
    @State private var username: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    
    @Environment(\.presentationMode) var presentationMode // Allows navigation back
    @State private var navigateToHome = false  // State for navigation

    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.cyan.opacity(0.6)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    // Back Button (Navigates back to doctor_menu)
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss() // Go back
                        }) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)
                                .padding(.leading, 20)
                                .shadow(color: .black.opacity(0.6), radius: 5, x: 0, y: 3)
                        }
                        Spacer()
                    }
                    .padding(.top, 10) // Move arrow upwards
                    
                    Spacer()
                    
                    // Header
                    Text("Change Password")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.5), radius: 4, x: 0, y: 3)
                        .padding(.bottom, 20)
                    
                    // Input Fields
                    CustomTextField(icon: "person.fill", placeholder: "Enter Username", text: $username)
                    CustomSecureField(icon: "lock.fill", placeholder: "Enter New Password", text: $newPassword)
                    CustomSecureField(icon: "lock.fill", placeholder: "Re-enter Password", text: $confirmPassword)
                    
                    // NavigationLink to doctor_home (Triggered when navigateToHome = true)
                    NavigationLink(destination: DoctorHome(), isActive: $navigateToHome) {
                        EmptyView()
                    }
                    
                    // Reset Password Button
                    Button(action: {
                        print("Password Reset Attempted")
                        navigateToHome = true // Triggers navigation
                    }) {
                        Text("Reset Password")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.9), Color.pink.opacity(0.7)]),
                                                       startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(15)
                            .shadow(color: .black.opacity(0.4), radius: 5, x: 0, y: 3)
                            .padding(.horizontal, 40)
                    }
                    .padding(.top, 15)
                    
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.horizontal, 20)
            }
        }
        .navigationBarBackButtonHidden(true) // Hides default back button
        .interactiveDismissDisabled(true)
    }
}

// Custom TextField
struct CustomTextField: View {
    var icon: String
    var placeholder: String
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.white)
                .frame(width: 35)
            
            TextField(placeholder, text: $text)
                .textFieldStyle(PlainTextFieldStyle())
                .foregroundColor(.white)
                .font(.system(size: 20, weight: .medium))
                .padding()
                .background(Color.white.opacity(0.2))
                .cornerRadius(12)
        }
        .frame(height: 55)
        .padding(.horizontal, 30)
    }
}

// Custom SecureField
struct CustomSecureField: View {
    var icon: String
    var placeholder: String
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.white)
                .frame(width: 35)
            
            SecureField(placeholder, text: $text)
                .textFieldStyle(PlainTextFieldStyle())
                .foregroundColor(.white)
                .font(.system(size: 20, weight: .medium))
                .padding()
                .background(Color.white.opacity(0.2))
                .cornerRadius(12)
        }
        .frame(height: 55)
        .padding(.horizontal, 30)
    }
}

// Preview
struct DoctorChangePassword_Previews: PreviewProvider {
    static var previews: some View {
        DoctorChangePassword()
    }
}
