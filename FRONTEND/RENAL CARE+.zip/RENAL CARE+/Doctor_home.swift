import SwiftUI

struct DoctorHome: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    // Header with Status Bar (Menu Icon) and Profile Icon
                    HStack {
                        NavigationLink(destination: DoctorMenu().navigationBarBackButtonHidden(true)) {
                            Image(systemName: "line.horizontal.3") // Menu Icon
                                .resizable()
                                .frame(width: 30, height: 20)
                                .foregroundColor(.white)
                        }
                        Spacer()
                        Text("Dr. KRISH")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Spacer()
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.white)
                    }
                    .padding(.top, UIApplication.shared.windows.first?.safeAreaInsets.top ?? 0)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.9))
                    .edgesIgnoringSafeArea(.top)
                    
                    Text("Patient List")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 10)
                    
                    ScrollView {
                        VStack(spacing: 15) {
                            // First PatientCard navigates to "patient_monitoring" (back button enabled)
                            NavigationLink(destination: PatientMonitoring()) {
                                PatientCard(patientID: "192111", name: "John Doe", gender: "Male", imageName: "patient 1")
                            }
                            
                            // Other patient cards as buttons
                            PatientCardButton(patientID: "192102", name: "Elly", gender: "Female", imageName: "patient")
                            PatientCardButton(patientID: "190129", name: "Mike Smith", gender: "Male", imageName: "patient 1")
                            PatientCardButton(patientID: "190130", name: "Hamilton", gender: "Male", imageName: "patient 1")
                            PatientCardButton(patientID: "190151", name: "Emma", gender: "Female", imageName: "patient")
                        }
                    }
                    .padding()
                    
                    // Buttons: Add Patient & Show All
                    HStack {
                        NavigationLink(destination: AddPatient().navigationBarBackButtonHidden(true)) {
                            Text("Add Patient")
                                .font(.title2)
                                .foregroundColor(.white)
                                .frame(width: 150, height: 50)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing)
                                )
                                .cornerRadius(25)
                                .shadow(radius: 5)
                        }
                        Spacer()
                        NavigationLink(destination: SearchPatients().navigationBarBackButtonHidden(true)) {
                            Text("Show All")
                                .font(.title2)
                                .foregroundColor(.white)
                                .frame(width: 150, height: 50)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]), startPoint: .leading, endPoint: .trailing)
                                )
                                .cornerRadius(25)
                                .shadow(radius: 5)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

struct PatientCardButton: View {
    var patientID: String
    var name: String
    var gender: String
    var imageName: String
    
    var body: some View {
        Button(action: {
            print("\(name)'s card tapped!")
        }) {
            PatientCard(patientID: patientID, name: name, gender: gender, imageName: imageName)
        }
    }
}

struct PatientCard: View {
    var patientID: String
    var name: String
    var gender: String
    var imageName: String
    
    var body: some View {
        HStack {
            Image(imageName) // Load patient image
                .resizable()
                .scaledToFill()
                .frame(width: 70, height: 70)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 2))
                .shadow(radius: 5)
                .padding()
            
            VStack(alignment: .leading) {
                Text("Patient ID: \(patientID)")
                    .font(.headline)
                    .foregroundColor(.white)
                Text("Name: \(name)")
                    .font(.subheadline)
                    .foregroundColor(.white)
                Text("Gender: \(gender)")
                    .font(.subheadline)
                    .foregroundColor(.white)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.blue.opacity(0.5)) // Slightly darker background for contrast
        .cornerRadius(20)
        .shadow(radius: 3)
    }
}

struct DoctorHome_Previews: PreviewProvider {
    static var previews: some View {
        DoctorHome()
    }
}
