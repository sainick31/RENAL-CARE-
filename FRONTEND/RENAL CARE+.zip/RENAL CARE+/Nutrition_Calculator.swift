import SwiftUI

struct NutritionCalculator: View {
    @State private var searchText: String = ""
    
    var filteredData: [NutritionItem] {
        if searchText.isEmpty {
            return nutritionData
        } else {
            return nutritionData.filter { $0.food.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                // Top Bar with Back Button Navigating to "patient_home"
                HStack {
                    NavigationLink(destination: PatientHome()) {
                        Image(systemName: "chevron.left.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .padding()
                    }
                    Spacer()
                }
                .padding(.horizontal)
                
                // Header
                Text("🥗 Patient's Nutrition Table")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.8))
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                // Search Bar
                TextField("Search food...", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                
                ScrollView {
                    VStack(spacing: 15) {
                        ForEach(filteredData) { item in
                            NutritionCard(item: item)
                        }
                    }
                    .padding()
                }
            }
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.teal.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
            )
        }
    }
}

// Nutrition Card View
struct NutritionCard: View {
    var item: NutritionItem
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: item.icon)
                    .resizable()
                    .frame(width: 25, height: 25)
                    .foregroundColor(.green)
                
                Text(item.food)
                    .font(.headline)
                    .bold()
            }
            
            ProgressBar(title: "Carbs", value: item.carbohydrate, maxValue: 100, color: .blue)
            ProgressBar(title: "Calories", value: Double(item.calorie), maxValue: 500, color: .red)
            ProgressBar(title: "Protein", value: item.protein, maxValue: 50, color: .orange)
            ProgressBar(title: "Sodium", value: Double(item.sodium), maxValue: 1500, color: .purple)
            ProgressBar(title: "Potassium", value: Double(item.potassium), maxValue: 2000, color: .yellow)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 4)
        .padding(.horizontal)
    }
}

// Progress Bar View
struct ProgressBar: View {
    var title: String
    var value: Double
    var maxValue: Double
    var color: Color
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("\(title): \(String(format: "%.2f", value))")
                .font(.caption)
                .bold()
            
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 6)
                        .frame(width: geo.size.width, height: 8)
                        .foregroundColor(color.opacity(0.2))
                    
                    RoundedRectangle(cornerRadius: 6)
                        .frame(width: min(CGFloat(value / maxValue) * geo.size.width, geo.size.width), height: 8)
                        .foregroundColor(color)
                }
            }
            .frame(height: 8)
        }
    }
}

// Preview
struct NutritionCalculator_Previews: PreviewProvider {
    static var previews: some View {
        NutritionCalculator()
    }
}
