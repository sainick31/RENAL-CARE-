import SwiftUI

struct PatientMenu: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(spacing: 20) {
                    // Top Bar with Back Button
                    HStack {
                        NavigationLink(destination: PatientHome().navigationBarBackButtonHidden(true)) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)
                        }
                        .padding(.leading)
                        Spacer()
                    }
                    .padding(.top, -100)

                    // Header Title
                    Text("Patient Menu")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.bottom, 20)

                    // Menu Options as Navigation Links
                    VStack(spacing: 20) {
                        NavigationLink(destination: PatientChangePassword().navigationBarBackButtonHidden(true)) {
                            MenuOption(icon: "key.fill", title: "Change Password") {}
                        }

                        NavigationLink(destination: PatientProfile().navigationBarBackButtonHidden(true)) {
                            MenuOption(icon: "person.crop.circle", title: "Profile") {}
                        }

                        NavigationLink(destination: AIChatbot().navigationBarBackButtonHidden(true)) {
                            MenuOption(icon: "message.fill", title: "Chat with NutriBot") {}
                        }

                        NavigationLink(destination: PatientLogin().navigationBarBackButtonHidden(true)) {
                            MenuOption(icon: "arrow.right.square.fill", title: "Log Out") {}
                        }
                    }
                    .padding(.top, 20)
                }
                .padding()
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

// Custom Menu Option Component
struct MenuOption: View {
    var icon: String
    var title: String
    var action: () -> Void

    var body: some View {
        HStack {
            Image(systemName: icon)
                .resizable()
                .frame(width: 30, height: 30)
                .foregroundColor(.white)
                .padding()

            Text(title)
                .font(.title3)
                .bold()
                .foregroundColor(.white)
            Spacer()
        }
        .padding()
        .frame(width: 350, height: 70)
        .background(LinearGradient(gradient: Gradient(colors: [Color.purple, Color.blue]), startPoint: .leading, endPoint: .trailing))
        .cornerRadius(20)
    }
}

struct PatientMenu_Previews: PreviewProvider {
    static var previews: some View {
        PatientMenu()
    }
}
