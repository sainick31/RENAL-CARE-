import SwiftUI

struct ScheduleFrequency: View {
    @Environment(\.presentationMode) var presentationMode // To handle back button action
    @State private var selectedDays: Set<String> = [] // Track selected days

    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.2)]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 0) {
                // Top Blue Block (Decreased Height)
                ZStack {
                    VStack(spacing: 0) {
                        HStack {
                            // Back Button
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left.circle.fill")
                                    .font(.system(size: 35, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, 35)
                            .padding(.top, 45)

                            Spacer()
                        }
                        .padding(.top, 30) // Adjusted upward

                        // Header Title
                        Text("📋 Schedule Frequency")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.top, 40) // Reduced top padding
                    }
                    .padding(.bottom, 30) // Reduced bottom padding
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .clipShape(
                        RoundedCornerShape(cornerRadius: 30, corners: [.bottomLeft, .bottomRight])
                    ) // Curved bottom edges
                    .edgesIgnoringSafeArea(.top)
                }

                // Scrollable Content
                ScrollView {
                    VStack(spacing: 20) {
                        Spacer()

                        // Days of the Week Selection
                        VStack(spacing: 15) {
                            ForEach(daysOfWeek, id: \.self) { day in
                                Button(action: {
                                    if selectedDays.contains(day) {
                                        selectedDays.remove(day)
                                    } else {
                                        selectedDays.insert(day)
                                    }
                                }) {
                                    Text(day)
                                        .font(.system(size: 22, weight: .bold))
                                        .foregroundColor(.white)
                                        .frame(width: 260, height: 60)
                                        .background(
                                            LinearGradient(
                                                gradient: Gradient(colors: selectedDays.contains(day) ? [Color.green, Color.teal] : [Color.blue.opacity(0.8), Color.cyan.opacity(0.6)]),
                                                startPoint: .leading, endPoint: .trailing
                                            )
                                        )
                                        .cornerRadius(18)
                                        .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                                        .overlay(RoundedRectangle(cornerRadius: 18)
                                            .stroke(Color.white.opacity(0.8), lineWidth: 2))
                                        .animation(.easeInOut(duration: 0.2), value: selectedDays)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding(.top, -40)

                        Spacer()

                        // Stylish Dialysis Data Button
                        NavigationLink(destination: DialysisData()) {
                            Text("Dialysis Data")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(.white)
                                .frame(width: 280, height: 70)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.9), Color.blue.opacity(0.7)]),
                                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                                )
                                .cornerRadius(20)
                                .shadow(color: Color.black.opacity(0.4), radius: 6, x: 0, y: 6)
                                .overlay(RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.white.opacity(0.8), lineWidth: 2))
                                .scaleEffect(1.05)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .padding(.bottom, 40)
                    }
                    .padding()
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }

    let daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
}

// Custom Shape for Rounded Bottom Corners
struct RoundedCornerShape: Shape {
    var cornerRadius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: cornerRadius, height: cornerRadius)
        )
        return Path(path.cgPath)
    }
}

struct ScheduleFrequency_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ScheduleFrequency()
        }
    }
}
