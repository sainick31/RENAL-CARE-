import SwiftUI

struct Patient: Identifiable {
    let id = UUID()
    let patientID: String
    let name: String
    let gender: String
    let photo: String // Image file name
}

struct SearchPatients: View {
    @State private var searchText = ""
    
    let patients = [
        Patient(patientID: "192111", name: "John Doe", gender: "Male", photo: "patient 1"),
        Patient(patientID: "192102", name: "Elly Smith", gender: "Female", photo: "patient"),
        Patient(patientID: "190129", name: "Mike Johnson", gender: "Male", photo: "patient 1"),
        Patient(patientID: "194529", name: "Sarah Williams", gender: "Female", photo: "patient")
    ]

    var filteredPatients: [Patient] {
        if searchText.isEmpty {
            return patients
        } else {
            return patients.filter {
                $0.patientID.contains(searchText) ||
                $0.name.lowercased().contains(searchText.lowercased())
            }
        }
    }

    var body: some View {
        NavigationView {
            VStack {
                // Back Button (Navigates to Doctor Home)
                HStack {
                    NavigationLink(destination: DoctorHome().navigationBarBackButtonHidden(true)) {
                        Image(systemName: "chevron.left.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .shadow(radius: 5)
                    }
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 20)

                // Unique Header with Semi-Transparent Background
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.blue.opacity(0.9))
                        .frame(height: 70)
                        .shadow(radius: 5)

                    Text("👨‍⚕️ Patient List")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .shadow(radius: 2)

                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.white.opacity(0.2))
                        .frame(width: 160, height: 5)
                        .padding(.top, 50)
                }
                .padding(.horizontal)
                .padding(.top, 10)

                // Search Bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search patients...", text: $searchText)
                        .textFieldStyle(PlainTextFieldStyle())
                }
                .padding()
                .background(Color.white)
                .cornerRadius(25)
                .shadow(radius: 2)
                .padding(.horizontal)
                .padding(.top, 10)

                // Patient List with Larger Blocks and Profile Image
                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(filteredPatients.indices, id: \.self) { index in
                            if index == 0 {
                                NavigationLink(destination: PatientMonitoring().navigationBarBackButtonHidden(true)) {
                                    PatientRow(patient: filteredPatients[index])
                                }
                            } else {
                                PatientRow(patient: filteredPatients[index])
                            }
                        }
                    }
                    .padding(.top, 10)
                }
            }
            .background(
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.2)]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
            )
        }
    }
}

// Extracted Patient Row Component
struct PatientRow: View {
    var patient: Patient

    var body: some View {
        HStack(spacing: 20) {
            Image(patient.photo)
                .resizable()
                .scaledToFill()
                .frame(width: 70, height: 70)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 2))
                .shadow(radius: 3)
                .padding(5)

            VStack(alignment: .leading, spacing: 8) {
                Text("Patient ID: \(patient.patientID)")
                    .font(.headline)
                    .foregroundColor(.white)
                Text("Name: \(patient.name)")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.9))
                Text("Gender: \(patient.gender)")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.9))
            }
            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 100, alignment: .leading)
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.9), Color.blue]), startPoint: .leading, endPoint: .trailing)
        )
        .cornerRadius(20)
        .shadow(radius: 5)
        .padding(.horizontal)
    }
}

struct SearchPatients_Previews: PreviewProvider {
    static var previews: some View {
        SearchPatients()
    }
}
