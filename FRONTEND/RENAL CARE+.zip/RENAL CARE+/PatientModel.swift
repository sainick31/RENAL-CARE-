import Foundation

struct PatientModel: Identifiable {
    var id = UUID()
    var patientID: String
    var name: String
    var gender: String
}
