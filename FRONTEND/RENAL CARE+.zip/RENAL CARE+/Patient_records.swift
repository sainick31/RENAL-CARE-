import SwiftUI

struct PatientRecords: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var patientRecords: [DialysisRecord] = [
        DialysisRecord(date: "20/06/2024 - Monday", weight: "51 kgs", weightGain: "4 kgs", preBP: "119/70 mm Hg", postBP: "120/80 mm Hg"),
        DialysisRecord(date: "22/06/2024 - Wednesday", weight: "51 kgs", weightGain: "4 kgs", preBP: "117/80 mm Hg", postBP: "123/80 mm Hg")
    ]
    
    var body: some View {
        NavigationView {
            ZStack {
                // Gradient Background
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.cyan]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 20) {
                    // Header Positioned Higher
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white.opacity(0.2))
                            .frame(height: 130)
                            .shadow(radius: 5)
                            .offset(y: -30)
                        
                        HStack {
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }) {
                                Image(systemName: "chevron.left.circle.fill")
                                    .font(.system(size: 35))
                                    .foregroundColor(.white)
                            }
                            Spacer()
                            Text("📋 Patient Records")
                                .font(.custom("Doppio One", size: 28))
                                .foregroundColor(.white)
                            Spacer()
                        }
                        .padding(.horizontal)
                    }
                    .padding(.top, -30)
                    
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 20) {
                            // Case Sheet History
                            SectionHeader(title: "Case Sheet History")
                            InfoCard {
                                VStack(alignment: .center, spacing: 10) {
                                    Text("Co-morbidities")
                                        .font(.title2.bold())
                                        .foregroundColor(Color.blue)
                                    Text("CVA (Cerebro Vascular Disease)").bold()
                                    Text("CVC (Central Venous Catheter)").bold()
                                        .foregroundColor(Color.blue)
                                    Text("Right IJV (Internal Jugular Vein)").bold()
                                    Text("Right Femoral").bold()
                                    Text("Right Brachiocephalic Fistula").bold()
                                }
                            }
                            
                            // Dialysis Data (Dynamic from backend)
                            SectionHeader(title: "Dialysis Data")
                            ForEach(patientRecords) { record in
                                InfoCard {
                                    DialysisEntry(date: record.date, weight: record.weight, weightGain: record.weightGain, preBP: record.preBP, postBP: record.postBP)
                                }
                            }
                            
                            // Urine Output
                            SectionHeader(title: "Urine Output")
                            InfoCard {
                                VStack(alignment: .center, spacing: 10) {
                                    Text("20/06/2024").foregroundColor(Color.blue).bold()
                                    Text("Urine Output: 250 ml").bold()
                                }
                            }
                            
                            // Nutritional Assessment Tools
                            SectionHeader(title: "Nutritional Assessment Tools")
                            InfoCard {
                                VStack(alignment: .center, spacing: 10) {
                                    Text("20/06/2024").foregroundColor(Color.blue).bold()
                                    Text("Tricep Skinfold Thickness: 9 mm").bold()
                                    Text("Hand grip: 90 Kgs / 198 Lbs").bold()
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
        
        }
        .onAppear {
            fetchData()
        }
        .navigationBarBackButtonHidden(true)
    }
    
    // Simulated Backend Data Fetching
    func fetchData() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.patientRecords.append(
                DialysisRecord(date: "24/06/2024 - Friday", weight: "52 kgs", weightGain: "3 kgs", preBP: "118/75 mm Hg", postBP: "121/82 mm Hg")
            )
        }
    }
}

// Section Header Component
struct SectionHeader: View {
    var title: String
    var body: some View {
        Text(title)
            .font(.title2.bold())
            .foregroundColor(.white)
            .padding(.top, 5)
    }
}

// Info Card View for Styling
struct InfoCard<Content: View>: View {
    var content: () -> Content
    
    var body: some View {
        VStack {
            content()
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.white.opacity(0.9))
        .cornerRadius(15)
        .shadow(radius: 8)
    }
}

// Dialysis Entry Component
struct DialysisEntry: View {
    var date: String
    var weight: String
    var weightGain: String
    var preBP: String
    var postBP: String
    
    var body: some View {
        VStack(alignment: .center, spacing: 5) {
            Text(date).foregroundColor(Color.blue).bold()
            Text("Weight: \(weight)").bold()
            Text("Weight Gain: \(weightGain)").bold()
            Text("Pre-BP: \(preBP)").bold()
            Text("Post-BP: \(postBP)").bold()
        }
    }
}

// Dialysis Record Model
struct DialysisRecord: Identifiable {
    let id = UUID()
    var date: String
    var weight: String
    var weightGain: String
    var preBP: String
    var postBP: String
}

struct PatientRecords_Previews: PreviewProvider {
    static var previews: some View {
       PatientRecords()
    }
}
