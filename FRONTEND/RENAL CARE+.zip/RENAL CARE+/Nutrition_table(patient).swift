import SwiftUI

struct DuplicateNutritionTableView: View {
    @State private var navigateToPatientHome = false // State for navigation

    var body: some View {
        NavigationStack {
            VStack {
                // Top Bar with Larger Back Button
                HStack {
                    Button(action: {
                        print("Navigating back to patient_home") // Debugging
                        navigateToPatientHome = true // Navigate to patient_home
                    }) {
                        Image(systemName: "chevron.left.circle.fill")
                            .font(.largeTitle) // Increased size
                            .foregroundColor(.white)
                            .padding()
                    }
                    Spacer()
                }
                .padding(.horizontal)
                
                // Header
                Text("🥗 Nutrition Table")
                    .font(.title) // Increased font size
                    .bold()
                    .foregroundColor(.white)
                    .padding(8) // Reduced padding
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.8))
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Scrollable Table
                        ScrollView(.horizontal, showsIndicators: true) {
                            VStack(alignment: .leading, spacing: 0) {
                                // Table Header
                                HStack(spacing: 0) {
                                    TableCell(text: "📌 Meal", isHeader: true)
                                    TableCell(text: "🍽 Food", isHeader: true)
                                    TableCell(text: "🥔 Carbs (g)", isHeader: true)
                                    TableCell(text: "🔥 Cal", isHeader: true)
                                    TableCell(text: "💪 Protein (g)", isHeader: true)
                                    TableCell(text: "🧂 Sodium (mg)", isHeader: true)
                                    TableCell(text: "🍌 Potassium (mg)", isHeader: true)
                                }
                                .background(Color.gray.opacity(0.3))
                                
                                // Table Rows
                                ForEach(nutritionData) { item in
                                    HStack(spacing: 0) {
                                        TableCell(text: item.mealType)
                                        TableCellWithIcon(text: item.food, icon: item.icon)
                                        TableCell(text: String(format: "%.2f", item.carbohydrate))
                                        TableCell(text: "\(item.calorie)")
                                        TableCell(text: String(format: "%.2f", item.protein))
                                        TableCell(text: "\(item.sodium)")
                                        TableCell(text: "\(item.potassium)")
                                    }
                                    .background(Color.white)
                                    .border(Color.gray.opacity(0.3), width: 1)
                                }
                            }
                            .padding()
                        }
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                        .padding(.horizontal)
                        
                        // Deficiency Section
                        VStack(alignment: .center, spacing: 15) {
                            Text("⚠️ Deficiencies")
                                .font(.headline)
                                .foregroundColor(.red)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color.green.opacity(0.7)))

                            VStack(alignment: .leading, spacing: 15) {
                                HStack {
                                    Text("🔥 Calorie:").bold()
                                    Text("395 Kcal/Kg").foregroundColor(.red)
                                }
                                HStack {
                                    Text("💪 Protein:").bold()
                                    Text("18.49 g/Kg").foregroundColor(.red)
                                }
                            }
                            .padding(8)
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 3)
                            .frame(width: 220)
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                    }
                    .padding()
                }
                .navigationBarBackButtonHidden(true)
            }
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.cyan.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
            )
            .navigationDestination(isPresented: $navigateToPatientHome) {
                PatientHome().navigationBarBackButtonHidden(true) // Navigates to patient_home
            }
        }
    }
}

// Preview
struct DuplicateNutritionTableView_Previews: PreviewProvider {
    static var previews: some View {
        DuplicateNutritionTableView()
    }
}
