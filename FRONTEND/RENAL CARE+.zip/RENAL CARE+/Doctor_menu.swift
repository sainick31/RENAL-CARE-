import SwiftUI

struct DoctorMenu: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient background (60% blue, 40% cyan)
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), Color.purple.opacity(0.5)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    // Back Button with dedicated spacing
                    HStack {
                        NavigationLink(destination: DoctorHome().navigationBarBackButtonHidden(true)) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)
                                .shadow(color: .black.opacity(0.6), radius: 5, x: 0, y: 3)
                        }
                        .padding(.leading, 20) // Aligns button to the left
                        .padding(.top, 20) // Adds vertical spacing separately
                        
                        Spacer()
                    }
                    
                    Spacer().frame(height: 90) // Separate space below back button
                    
                    // Header with enhanced design
                    Text("Doctor's Menu")
                        .font(.system(size: 38, weight: .heavy))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.7), radius: 6, x: 0, y: 4)
                        .padding(.bottom, 40)
                    
                    // Menu buttons with improved design
                    VStack(spacing: 30) { // Added spacing between buttons
                        NavigationLink(destination: UploadVideos().navigationBarBackButtonHidden(true)) {
                            MenuButton(icon: "film.fill", title: "Upload Videos")
                        }
                        NavigationLink(destination: DoctorChangePassword().navigationBarBackButtonHidden(true)) {
                            MenuButton(icon: "key.fill", title: "Change Password")
                        }
                        NavigationLink(destination: DoctorLogin().navigationBarBackButtonHidden(true)) {
                            MenuButton(icon: "arrow.right.square.fill", title: "Log out")
                        }
                    }
                    
                    Spacer() // Ensures proper alignment
                }
                .padding(.horizontal, 20)
            }
        }
    }
}

// Menu Button with stylish design
struct MenuButton: View {
    var icon: String
    var title: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .resizable()
                .frame(width: 30, height: 30) // Larger icons
                .foregroundColor(.white)
            
            Text(title)
                .font(.system(size: 24, weight: .bold)) // Larger text
                .foregroundColor(.white)
            
            Spacer()
        }
        .padding()
        .frame(width: 320, height: 90) // Larger button
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.black.opacity(0.4)) // Darker contrast
                .shadow(color: .black.opacity(0.6), radius: 8, x: 0, y: 4)
        )
    }
}

struct DoctorMenu_Previews: PreviewProvider {
    static var previews: some View {
        DoctorMenu()
    }
}
