import SwiftUI

struct NutritionTableView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // Top Bar with Larger Back Button
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left.circle.fill")
                        .font(.largeTitle) // Increased size
                        .foregroundColor(.white)
                        .padding()
                }
                Spacer()
            }
            .padding(.horizontal)
            
            // Header
            Text("🥗 Nutrition Table")
                .font(.title) // Increased font size
                .bold()
                .foregroundColor(.white)
                .padding(8) // Reduced padding
                .frame(maxWidth: .infinity)
                .background(Color.blue.opacity(0.8))
                .cornerRadius(10)
                .padding(.horizontal)
            
            ScrollView {
                VStack(spacing: 20) {
                    // Scrollable Table
                    ScrollView(.horizontal, showsIndicators: true) {
                        VStack(alignment: .leading, spacing: 0) {
                            // Table Header
                            HStack(spacing: 0) {
                                TableCell(text: "📌 Meal", isHeader: true)
                                TableCell(text: "🍽 Food", isHeader: true)
                                TableCell(text: "🥔 Carbs (g)", isHeader: true)
                                TableCell(text: "🔥 Cal", isHeader: true)
                                TableCell(text: "💪 Protein (g)", isHeader: true)
                                TableCell(text: "🧂 Sodium (mg)", isHeader: true)
                                TableCell(text: "🍌 Potassium (mg)", isHeader: true)
                            }
                            .background(Color.gray.opacity(0.3))
                            
                            // Table Rows
                            ForEach(nutritionData) { item in
                                HStack(spacing: 0) {
                                    TableCell(text: item.mealType)
                                    TableCellWithIcon(text: item.food, icon: item.icon)
                                    TableCell(text: String(format: "%.2f", item.carbohydrate))
                                    TableCell(text: "\(item.calorie)")
                                    TableCell(text: String(format: "%.2f", item.protein))
                                    TableCell(text: "\(item.sodium)")
                                    TableCell(text: "\(item.potassium)")
                                }
                                .background(Color.white)
                                .border(Color.gray.opacity(0.3), width: 1)
                            }
                        }
                        .padding()
                    }
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // Deficiency Section
                    VStack(alignment: .center, spacing: 15) {
                        Text("⚠️ Deficiencies")
                            .font(.headline)
                            .foregroundColor(.red)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10).fill(Color.green.opacity(0.7)))

                        VStack(alignment: .leading, spacing: 15) {
                            HStack {
                                Text("🔥 Calorie:").bold()
                                Text("395 Kcal/Kg").foregroundColor(.red)
                            }
                            HStack {
                                Text("💪 Protein:").bold()
                                Text("18.49 g/Kg").foregroundColor(.red)
                            }
                        }
                        .padding(8)
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 3)
                        .frame(width: 220)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                }
                .padding()
            }
            .navigationBarBackButtonHidden(true)
        }
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.4)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
    }
}

// Custom View for Table Cells
struct TableCell: View {
    var text: String
    var isHeader: Bool = false
    
    var body: some View {
        Text(text)
            .font(isHeader ? .headline : .body)
            .bold(isHeader)
            .frame(width: 150, height: 40) // Increased width for better visibility
            .multilineTextAlignment(.center)
            .background(isHeader ? Color.gray.opacity(0.3) : Color.white)
            .border(Color.gray.opacity(0.3), width: 1)
    }
}

// Custom View for Table Cells with Icons
struct TableCellWithIcon: View {
    var text: String
    var icon: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .resizable()
                .frame(width: 18, height: 18)
            Text(text)
                .lineLimit(1)
                .truncationMode(.tail)
        }
        .frame(width: 150, height: 40) // Same width as other cells
        .background(Color.white)
        .border(Color.gray.opacity(0.3), width: 1)
    }
}

// Sample Data Model
struct NutritionItem: Identifiable {
    let id = UUID()
    let mealType: String
    let food: String
    let carbohydrate: Double
    let calorie: Int
    let protein: Double
    let sodium: Int
    let potassium: Int
    let icon: String
}

// Sample Data
let nutritionData: [NutritionItem] = [
    // Early Morning
    .init(mealType: "🌅 Early Morning", food: "Dates", carbohydrate: 75.03, calorie: 282, protein: 2.45, sodium: 2, potassium: 656, icon: "leaf.fill"),
    .init(mealType: "🌅 Early Morning", food: "Apple", carbohydrate: 25.00, calorie: 95, protein: 0.5, sodium: 2, potassium: 195, icon: "applelogo"),
    .init(mealType: "🌅 Early Morning", food: "Almonds (5 pcs)", carbohydrate: 1.2, calorie: 35, protein: 1.3, sodium: 1, potassium: 60, icon: "leaf.fill"),
    .init(mealType: "🌅 Early Morning", food: "Unsalted Cashews (5 pcs)", carbohydrate: 3.0, calorie: 43, protein: 1.2, sodium: 3, potassium: 45, icon: "leaf"),

    // Breakfast
    .init(mealType: "🍳 Breakfast", food: "Idli", carbohydrate: 47.35, calorie: 242, protein: 11.44, sodium: 47, potassium: 411, icon: "baguette.fill"),
    .init(mealType: "🍳 Breakfast", food: "Oatmeal", carbohydrate: 27.00, calorie: 154, protein: 6.00, sodium: 2, potassium: 164, icon: "bowl.fill"),
    .init(mealType: "🍳 Breakfast", food: "Egg White (2)", carbohydrate: 0.4, calorie: 34, protein: 7.2, sodium: 110, potassium: 108, icon: "egg.fill"),
    .init(mealType: "🍳 Breakfast", food: "Toasted Brown Bread", carbohydrate: 14.00, calorie: 69, protein: 2.9, sodium: 100, potassium: 50, icon: "baguette.fill"),

    // Lunch
    .init(mealType: "🍛 Lunch", food: "Biryani", carbohydrate: 48.07, calorie: 348, protein: 15.90, sodium: 318, potassium: 502, icon: "fork.knife"),
    .init(mealType: "🍛 Lunch", food: "Grilled Chicken", carbohydrate: 0.00, calorie: 165, protein: 31.00, sodium: 74, potassium: 256, icon: "flame"),
    .init(mealType: "🍛 Lunch", food: "White Rice", carbohydrate: 45.00, calorie: 205, protein: 4.3, sodium: Int(0.6), potassium: 55, icon: "leaf"),
    .init(mealType: "🍛 Lunch", food: "Steamed Fish", carbohydrate: 0.00, calorie: 150, protein: 22.00, sodium: 50, potassium: 320, icon: "flame"),

    // Meal Type
    .init(mealType: "🥣 Meal Type", food: "Curd Rice", carbohydrate: 18.07, calorie: 130, protein: 5.73, sodium: 28, potassium: 161, icon: "bowl.fill"),
    .init(mealType: "🥣 Meal Type", food: "Chapati", carbohydrate: 13.00, calorie: 68, protein: 2.34, sodium: 409, potassium: 206, icon: "circle.grid.cross.fill"),
    .init(mealType: "🥣 Meal Type", food: "Dal (Lentil Soup)", carbohydrate: 26.00, calorie: 198, protein: 9.0, sodium: 25, potassium: 400, icon: "drop.fill"),
    .init(mealType: "🥣 Meal Type", food: "Boiled Vegetables", carbohydrate: 12.0, calorie: 50, protein: 2.0, sodium: 20, potassium: 140, icon: "leaf.fill"),

    // Snacks
    .init(mealType: "🍟 Snacks", food: "Samosa", carbohydrate: 32.21, calorie: 308, protein: 4.67, sodium: 423, potassium: 189, icon: "takeoutbag.and.cup.and.straw.fill"),
    .init(mealType: "🍟 Snacks", food: "Popcorn (Unsalted)", carbohydrate: 22.00, calorie: 110, protein: 3.00, sodium: 1, potassium: 93, icon: "popcorn.fill"),
    .init(mealType: "🍟 Snacks", food: "Unsalted Crackers", carbohydrate: 22.00, calorie: 108, protein: 2.2, sodium: 30, potassium: 45, icon: "leaf"),
    .init(mealType: "🍟 Snacks", food: "Boiled Sweet Potato", carbohydrate: 26.0, calorie: 114, protein: 2.1, sodium: 41, potassium: 230, icon: "leaf"),

    // Dinner
    .init(mealType: "🌙 Dinner", food: "Chapati", carbohydrate: 13.00, calorie: 68, protein: 2.34, sodium: 409, potassium: 206, icon: "circle.grid.cross.fill"),
    .init(mealType: "🌙 Dinner", food: "Grilled Fish", carbohydrate: 0.00, calorie: 206, protein: 22.00, sodium: 59, potassium: 336, icon: "flame"),
    .init(mealType: "🌙 Dinner", food: "Boiled Vegetables", carbohydrate: 12.0, calorie: 50, protein: 2.0, sodium: 20, potassium: 140, icon: "leaf.fill"),
    .init(mealType: "🌙 Dinner", food: "Tofu Stir Fry", carbohydrate: 9.0, calorie: 94, protein: 10.0, sodium: 8, potassium: 120, icon: "flame"),

    // Fluids
    .init(mealType: "🥤 Fluids", food: "Lemon Juice", carbohydrate: 4.06, calorie: 12, protein: 0.18, sodium: 1, potassium: 103, icon: "cup.and.saucer.fill"),
    .init(mealType: "🥤 Fluids", food: "Coconut Water (Limited)", carbohydrate: 9.0, calorie: 45, protein: 2.0, sodium: 30, potassium: 250, icon: "drop.fill"),
    .init(mealType: "🥤 Fluids", food: "Almond Milk", carbohydrate: 1.0, calorie: 30, protein: 1.0, sodium: 150, potassium: 30, icon: "cup.and.saucer.fill"),
    .init(mealType: "🥤 Fluids", food: "Green Tea (No Sugar)", carbohydrate: 0.5, calorie: 2, protein: 0.1, sodium: 3, potassium: 28, icon: "cup.and.saucer.fill"),

    // Total
    .init(mealType: "📊 Total", food: "", carbohydrate: 300.00, calorie: 1600, protein: 65.00, sodium: 5000, potassium: 3000, icon: "chart.bar.fill")
]


struct NutritionTableView_Previews: PreviewProvider {
    static var previews: some View {
        NutritionTableView()
    }
}
