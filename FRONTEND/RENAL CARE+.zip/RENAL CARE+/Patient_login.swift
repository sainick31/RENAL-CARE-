import SwiftUI

struct PatientLogin: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var isLoading: Bool = false
    @State private var loginError: String?
    @State private var isLoggedIn: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.7)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .edgesIgnoringSafeArea(.all)
                
                VStack {
                    HStack {
                        NavigationLink(destination: HomeScreen().navigationBarBackButtonHidden(true)) {
                            Image(systemName: "chevron.left.circle.fill")
                                .resizable()
                                .frame(width: 35, height: 35)
                                .foregroundColor(.white)
                                .shadow(radius: 5)
                        }
                        Spacer()
                        Text("Patient Login")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Spacer()
                        Image(systemName: "arrow.left")
                            .opacity(0)
                    }
                    .padding()
                    
                    Spacer().frame(height: 140)
                    
                    Image("patient")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)
                    
                    Spacer().frame(height: 20)
                    
                    TextField("Username", text: $username)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.6), lineWidth: 1))
                        .foregroundColor(.white)
                    
                    SecureField("Password", text: $password)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.6), lineWidth: 1))
                        .foregroundColor(.white)
                    
                    Spacer().frame(height: 20)
                    
                    if let error = loginError {
                        Text(error)
                            .foregroundColor(.red)
                            .padding()
                    }
                    
                    if isLoading {
                        ProgressView()
                    } else {
                        Button(action: login) {
                            Text("Login")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(width: 150, height: 50)
                                .background(Color.blue)
                                .cornerRadius(25)
                                .shadow(radius: 5)
                        }
                    }
                    
                    Spacer()
                    
                    Image("nutrition_banner")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 150)
                    
                    Spacer().frame(height: 20)
                }
                .padding()
                .background(
                    NavigationLink(destination: PatientHome().navigationBarBackButtonHidden(true), isActive: $isLoggedIn) {
                        EmptyView()
                    }
                )
            }
        }
        .navigationBarHidden(true)
    }
    
    func login() {
        isLoading = true
        loginError = nil
        
        guard let url = URL(string: "http://localhost/nutrition/patient_login.php") else {
            loginError = "Invalid URL"
            isLoading = false
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = ""
        body += "--\(boundary)\r\n"
        body += "Content-Disposition: form-data; name=\"patient_id\"\r\n\r\n\(username)\r\n"
        body += "--\(boundary)\r\n"
        body += "Content-Disposition: form-data; name=\"password\"\r\n\r\n\(password)\r\n"
        body += "--\(boundary)--\r\n"
        
        request.httpBody = body.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                isLoading = false
                
                if let error = error {
                    loginError = "Network error: \(error.localizedDescription)"
                    return
                }
                
                guard let data = data, let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    loginError = "Invalid response from server"
                    return
                }
                
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                       let success = json["status"] as? String, success.lowercased() == "true" {
                        isLoggedIn = true
                    } else {
                        loginError = "Invalid credentials"
                    }
                } catch {
                    loginError = "Error parsing response"
                }
            }
        }.resume()
    }
}

#Preview {
    PatientLogin()
}
