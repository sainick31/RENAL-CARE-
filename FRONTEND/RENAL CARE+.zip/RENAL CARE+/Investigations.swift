import SwiftUI

struct Investigations: View {
    @Environment(\.presentationMode) var presentationMode  // For manual back navigation
    @State private var navigateToDoctorHome = false  // For manual navigation

    var body: some View {
        ZStack {
            // Gradient Background
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.7), Color.purple.opacity(0.4)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                // Top Header Bar with Custom Back Button
                ZStack {
                    Color.blue.opacity(0.9)
                        .frame(height: 165)
                        .clipShape(RoundedRectangle(cornerRadius: 40))
                        .ignoresSafeArea()

                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()  // Custom Back Navigation
                        }) {
                            Image(systemName: "chevron.left.circle.fill")
                                .foregroundColor(.white)
                                .font(.system(size: 35, weight: .bold))
                        }
                        Spacer()

                        HStack(spacing: 10) {
                            Text("🩺") // Medical Emoji
                            Text("Investigations")
                                .font(.system(size: 28, weight: .bold))
                        }
                        .foregroundColor(.white)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 15).fill(Color.orange.opacity(1.0)))
                        .shadow(radius: 5)

                        Spacer()
                    }
                    .padding(.horizontal, 30)
                    .offset(y: -15)
                }

                ScrollView {
                    VStack(spacing: 20) {
                        // Investigations List
                        Group {
                            investigationsRow(title: "Hemoglobin")
                            investigationsRow(title: "PCV")
                            investigationsRow(title: "Total WBC count")
                            investigationsRow(title: "Creatinine")
                            investigationsRow(title: "Potassium")
                            investigationsRow(title: "Serum Cholesterol")
                            investigationsRow(title: "Serum albumin")
                            investigationsRow(title: "Bicarbonate")
                        }
                        .padding(.horizontal, 20)

                        // ECHO Section
                        Text("ECHO")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(Color.blue)
                            .padding(.top, 10)

                        // Ejection Fraction Input
                        HStack {
                            Text("Ejection Fraction")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.black)
                            Spacer()
                            TextField("Enter Value", text: .constant(""))
                                .frame(width: 100, height: 40)
                                .padding(.horizontal, 10)
                                .background(Color.white.opacity(0.8))
                                .cornerRadius(10)
                                .shadow(radius: 3)
                            Text("%")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.black)
                        }
                        .padding(.horizontal, 40)

                        // Save Button Navigation
                        NavigationLink(destination: DoctorHome(), isActive: $navigateToDoctorHome) {
                            EmptyView()
                        }
                        .hidden()

                        Button(action: {
                            navigateToDoctorHome = true  // Navigate manually
                        }) {
                            HStack {
                                Image(systemName: "tray.and.arrow.down.fill")
                                    .font(.system(size: 22))
                                Text("Save")
                                    .font(.system(size: 24, weight: .bold))
                            }
                            .foregroundColor(.white)
                            .frame(width: 180, height: 55)
                            .background(Color.green.opacity(0.9))
                            .cornerRadius(15)
                            .shadow(radius: 5)
                        }
                        .padding(.top, 20)
                    }
                    .padding(.bottom, 40)
                }
            }
        }
        .navigationBarBackButtonHidden(true)  // Ensure default back button is hidden
    }
}

// Investigation Row Component
struct investigationsRow: View {
    var title: String
    @State private var inputText: String = ""

    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(.black)
                .frame(width: 200, alignment: .leading)
            Spacer()
            Text(":")
                .foregroundColor(.black)
                .font(.system(size: 20, weight: .semibold))
            TextField("Enter Value", text: $inputText)
                .frame(width: 150, height: 40)
                .padding(.horizontal, 10)
                .background(Color.white.opacity(0.8))
                .cornerRadius(10)
                .shadow(radius: 3)
                .foregroundColor(.black)
        }
        .padding(.vertical, 5)
    }
}

// Preview
struct Investigations_Previews: PreviewProvider {
    static var previews: some View {
        Investigations()
    }
}
