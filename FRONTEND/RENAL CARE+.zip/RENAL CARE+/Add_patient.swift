import SwiftUI

struct AddPatient: View {
    @State private var patientName = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var height = ""
    @State private var weight = ""
    @State private var bmi = ""
    @State private var dateOfInitiation = Date()
    @State private var dialysisVintage = ""
    @State private var mobileNumber = ""
    @State private var password = ""

    @State private var vegetarian = false
    @State private var nonVegetarian = false
    @State private var both = false

    @State private var navigateToDoctorHome = false
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.2)]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack {
                    BackButton()

                    Text("Add Patient")
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 20).fill(Color.pink).frame(width: 200, height: 50))

                    ScrollView {
                        VStack(spacing: 15) {
                            Group {
                                CustomLabeledTextField(label: "Patient Name", text: $patientName)
                                CustomLabeledTextField(label: "Age", text: $age)
                                    .keyboardType(.numberPad)
                                CustomLabeledTextField(label: "Gender", text: $gender)
                                CustomLabeledTextField(label: "Height (cm)", text: $height)
                                    .keyboardType(.decimalPad)
                                CustomLabeledTextField(label: "Weight (kg)", text: $weight)
                                    .keyboardType(.decimalPad)
                                CustomLabeledTextField(label: "BMI", text: $bmi)
                                    .keyboardType(.decimalPad)
                            }

                            VStack(alignment: .leading) {
                                DatePicker("Date of Initiation", selection: $dateOfInitiation, displayedComponents: .date)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                    .padding(.horizontal)
                            }

                            CustomLabeledTextField(label: "Dialysis Vintage", text: $dialysisVintage)

                            VStack(alignment: .leading) {
                                Text("Food Preferences")
                                    .font(.headline)
                                Toggle("Vegetarian", isOn: $vegetarian)
                                Toggle("Non-Vegetarian", isOn: $nonVegetarian)
                                Toggle("Both", isOn: $both)
                            }
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(10)
                            .padding(.horizontal)

                            CustomLabeledTextField(label: "Mobile Number", text: $mobileNumber)
                                .keyboardType(.phonePad)

                            VStack(alignment: .leading) {
                                Text("    Enter Password")
                                    .font(.headline)
                                SecureField("Password", text: $password)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                    .padding(.horizontal)
                            }

                            if let error = errorMessage {
                                Text(error)
                                    .foregroundColor(.red)
                                    .bold()
                                    .padding()
                            }

                            Button(action: addPatient) {
                                if isLoading {
                                    ProgressView()
                                } else {
                                    Text("Add")
                                        .font(.title2)
                                        .bold()
                                        .padding()
                                        .frame(maxWidth: .infinity)
                                        .background(Color.blue)
                                        .foregroundColor(.white)
                                        .cornerRadius(10)
                                        .padding(.horizontal)
                                }
                            }
                        }
                        .padding(.vertical)
                    }
                }
            }
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $navigateToDoctorHome) {
                DoctorHome().navigationBarBackButtonHidden(true)
            }
        }
    }

    func addPatient() {
        guard validateFields() else { return }

        isLoading = true
        errorMessage = nil

        let url = URL(string: "http://localhost/nutrition/add_patient.php")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let formData: [String: String] = [
            "patient_name": patientName,
            "age": age,
            "gender": gender,
            "height": height,
            "weight": weight,
            "body_mass_index": bmi,
            "date_of_initiation": formatDate(dateOfInitiation),
            "dialysis_vintage": dialysisVintage,
            "vegetarian": vegetarian ? "yes" : "no",
            "non_vegetarian": nonVegetarian ? "yes" : "no",
            "both_food": both ? "yes" : "no",
            "mobile_number": mobileNumber,
            "password": password
        ]

        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        for (key, value) in formData {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                isLoading = false
            }

            if let error = error {
                DispatchQueue.main.async {
                    errorMessage = "Network error: \(error.localizedDescription)"
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    errorMessage = "No response from server."
                }
                return
            }

            do {
                let result = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                if let status = result?["status"] as? Bool, status {
                    DispatchQueue.main.async {
                        navigateToDoctorHome = true
                    }
                } else {
                    DispatchQueue.main.async {
                        errorMessage = result?["message"] as? String ?? "Unknown error."
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    errorMessage = "Invalid response format."
                }
            }
        }.resume()
    }

    func validateFields() -> Bool {
        if patientName.isEmpty || age.isEmpty || gender.isEmpty || height.isEmpty || weight.isEmpty || bmi.isEmpty || mobileNumber.isEmpty || password.isEmpty {
            errorMessage = "All fields are required."
            return false
        }

        if Int(age) == nil || Int(age)! < 0 {
            errorMessage = "Age must be a valid number."
            return false
        }

        if Double(height) == nil || Double(height)! <= 0 {
            errorMessage = "Height must be a valid positive number."
            return false
        }

        if Double(weight) == nil || Double(weight)! <= 0 {
            errorMessage = "Weight must be a valid positive number."
            return false
        }

        if mobileNumber.count != 10 || Int(mobileNumber) == nil {
            errorMessage = "Enter a valid 10-digit mobile number."
            return false
        }

        return true
    }

    func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
}

struct BackButton: View {
    var body: some View {
        HStack {
            NavigationLink(destination: DoctorHome()) {
                Image(systemName: "chevron.left.circle.fill")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding()
            }
            Spacer()
        }
    }
}

struct CustomLabeledTextField: View {
    var label: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(label)
                .font(.headline)
            TextField("", text: $text)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
        }
        .padding(.horizontal)
    }
}

// PREVIEW
struct AddPatient_Previews: PreviewProvider {
    static var previews: some View {
        AddPatient()
    }
}
