import SwiftUI
import UIKit

struct PatientHome: View {
    @State private var patientName: String = "John Doe"
    @State private var profileImage: Image? = nil
    @State private var showImagePicker: Bool = false
    @State private var inputImage: UIImage?
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    VStack {
                        Spacer().frame(height: 70)
                        VStack {
                            HStack {
                                NavigationLink(destination: PatientMenu().navigationBarBackButtonHidden(true)) {
                                    Image(systemName: "line.horizontal.3")
                                        .resizable()
                                        .frame(width: 30, height: 20)
                                        .foregroundColor(.white)
                                }
                                Spacer()
                                Text(patientName)
                                    .font(.title.bold())
                                    .foregroundColor(.white)
                                Spacer()
                                ZStack {
                                    if let profileImage = profileImage {
                                        profileImage
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 80, height: 80)
                                            .clipShape(Circle())
                                            .overlay(Circle().stroke(Color.white, lineWidth: 2))
                                            .onTapGesture { showImagePicker = true }
                                    } else {
                                        Image("patient 1")
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 80, height: 80)
                                            .clipShape(Circle())
                                            .overlay(Circle().stroke(Color.white, lineWidth: 2))
                                            .onTapGesture { showImagePicker = true }
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        .padding(.bottom, 20)
                    }
                    .frame(height: 180)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .shadow(radius: 5)
                    .edgesIgnoringSafeArea(.top)
                    
                    ScrollView {
                        VStack(spacing: 25) {
                            NavigationLink(destination: NutritionCalculator().navigationBarBackButtonHidden(true)) {
                                FeatureCard(title: "Nutrition Calculator", icon: "chart.bar.fill", color: .pink, alignLeft: true)
                            }
                            NavigationLink(destination: AwarenessVideos().navigationBarBackButtonHidden(true)) {
                                FeatureCard(title: "Watch Awareness Videos", icon: "play.rectangle.fill", color: .purple, alignLeft: false)
                            }
                            NavigationLink(destination: DuplicateNutritionTableView().navigationBarBackButtonHidden(true)) {
                                FeatureCard(title: "Nutrition Table", icon: "book.fill", color: .orange, alignLeft: true)
                            }
                            NavigationLink(destination: NutritionDeficiency().navigationBarBackButtonHidden(true)) {
                                FeatureCard(title: "Nutritional Deficiency", icon: "pills.fill", color: .green, alignLeft: false)
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 20)
                    }
                }
            }
            .sheet(isPresented: $showImagePicker, onDismiss: loadImage) {
                ImagePicker(image: $inputImage)
            }
        }
    }
    
    func loadImage() {
        guard let inputImage = inputImage else { return }
        profileImage = Image(uiImage: inputImage)
    }
}

struct FeatureCard: View {
    var title: String
    var icon: String
    var color: Color
    var alignLeft: Bool

    var body: some View {
        HStack {
            if alignLeft {
                FeatureIcon(icon: icon, color: color)
            }
            Text(title)
                .font(.title.bold())
                .foregroundColor(.black)
                .padding()
            if !alignLeft {
                FeatureIcon(icon: icon, color: color)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 120)
        .background(Color.white.opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: 25))
        .shadow(radius: 5)
        .padding(.horizontal)
    }
}

struct FeatureIcon: View {
    var icon: String
    var color: Color
    
    var body: some View {
        Image(systemName: icon)
            .resizable()
            .frame(width: 70, height: 70)
            .foregroundColor(.white)
            .padding()
            .background(color)
            .clipShape(Circle())
            .padding(.horizontal, 10)
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.presentationMode) var presentationMode
    
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker
        
        init(parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage
            }
            parent.presentationMode.wrappedValue.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.allowsEditing = false
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
}

struct PatientHome_Previews: PreviewProvider {
    static var previews: some View {
        PatientHome()
    }
}
