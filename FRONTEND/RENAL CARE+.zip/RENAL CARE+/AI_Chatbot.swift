import SwiftUI

// MARK: - Chat Message Model
struct ChatMessage: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool
}

// MARK: - Main Chat View
struct AIChatbot: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var messages: [ChatMessage] = [
        ChatMessage(text: "Hi! How can I assist you today?", isUser: false)
    ]
    @State private var inputText: String = ""
    @State private var isTyping: Bool = false

    var chatbotName: String = "NutriBot"

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.indigo.opacity(0.9), Color.cyan.opacity(0.7)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 30) {
                // Header
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(14)
                            .background(Color.white.opacity(0.25))
                            .clipShape(Circle())
                    }

                    Spacer()

                    HStack(spacing: 12) {
                        Text("🤖")
                            .font(.system(size: 28))
                        Text(chatbotName)
                            .font(.system(size: 28, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                            .tracking(1.2)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 15)
                    .background(Color.black.opacity(0.25))
                    .clipShape(RoundedRectangle(cornerRadius: 30))
                    .offset(x: -10)

                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 10)
                .padding(.horizontal, 26)

                // Chat Area
                ScrollViewReader { scrollView in
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(messages) { message in
                                MessageBubble(message: message)
                                    .transition(.move(edge: .bottom))
                                    .id(message.id)
                            }

                            if isTyping {
                                TypingIndicator()
                                    .padding(.top, 10)
                                    .transition(.opacity)
                            }
                        }
                        .padding(.top, 10)
                        .padding(.bottom, 8)
                    }
                    .onChange(of: messages.count) { _ in
                        withAnimation {
                            scrollView.scrollTo(messages.last?.id, anchor: .bottom)
                        }
                    }
                }

                // Input Field
                HStack(spacing: 12) {
                    TextField("Type your message...", text: $inputText)
                        .padding()
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        .font(.body)
                        .foregroundColor(.primary)

                    Button(action: sendMessage) {
                        Image(systemName: "paperplane.fill")
                            .font(.title3)
                            .foregroundColor(.white)
                            .padding(12)
                            .background(Color.blue)
                            .clipShape(Circle())
                    }
                    .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding(.horizontal)
                .padding(.bottom, 16)
            }
        }
    }

    // MARK: - Send Message to PHP Backend
    func sendMessage() {
        guard !inputText.trimmingCharacters(in: .whitespaces).isEmpty else { return }

        let userMessage = ChatMessage(text: inputText, isUser: true)
        messages.append(userMessage)

        let userQuestion = inputText
        inputText = ""
        isTyping = true

        guard let url = URL(string: "http://localhost/nutrition/ai_chatbot.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = ""
        body += "--\(boundary)\r\n"
        body += "Content-Disposition: form-data; name=\"qns\"\r\n\r\n"
        body += "\(userQuestion)\r\n"
        body += "--\(boundary)--\r\n"

        request.httpBody = body.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                isTyping = false
            }

            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    messages.append(ChatMessage(text: "🚨 Server unreachable. Please try again.", isUser: false))
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let status = json["status"] as? Bool, status,
                   let dataArray = json["data"] as? [[String: Any]],
                   let answer = dataArray.first?["answer"] as? String {

                    DispatchQueue.main.async {
                        messages.append(ChatMessage(text: answer, isUser: false))
                    }
                } else {
                    DispatchQueue.main.async {
                        messages.append(ChatMessage(text: "❌ Failed to parse AI response.", isUser: false))
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    messages.append(ChatMessage(text: "💥 JSON decoding error: \(error.localizedDescription)", isUser: false))
                }
            }
        }.resume()
    }
}

// MARK: - Custom Message Bubble View
struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isUser { Spacer() }

            Text(message.text)
                .padding(.vertical, 14)
                .padding(.horizontal, 18)
                .background(
                    message.isUser ? Color.blue : Color.white
                )
                .foregroundColor(message.isUser ? .white : .black)
                .font(.system(size: 17, weight: .medium))
                .clipShape(ChatBubbleShape(isUser: message.isUser))
                .frame(maxWidth: 320, alignment: message.isUser ? .trailing : .leading)
                .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)

            if !message.isUser { Spacer() }
        }
        .padding(.horizontal, 12)
    }
}

// MARK: - Custom Shape for Message Bubbles
struct ChatBubbleShape: Shape {
    var isUser: Bool

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let cornerRadius: CGFloat = 22

        if isUser {
            path.addRoundedRect(in: rect, topLeftRadius: cornerRadius, topRightRadius: cornerRadius, bottomLeftRadius: cornerRadius, bottomRightRadius: 4)
        } else {
            path.addRoundedRect(in: rect, topLeftRadius: cornerRadius, topRightRadius: cornerRadius, bottomLeftRadius: 4, bottomRightRadius: cornerRadius)
        }

        return path
    }
}

// MARK: - Corner Radius Extension
extension Path {
    mutating func addRoundedRect(in rect: CGRect,
                                 topLeftRadius: CGFloat,
                                 topRightRadius: CGFloat,
                                 bottomLeftRadius: CGFloat,
                                 bottomRightRadius: CGFloat) {
        self.move(to: CGPoint(x: rect.minX + topLeftRadius, y: rect.minY))
        self.addLine(to: CGPoint(x: rect.maxX - topRightRadius, y: rect.minY))
        self.addArc(center: CGPoint(x: rect.maxX - topRightRadius, y: rect.minY + topRightRadius),
                    radius: topRightRadius, startAngle: .degrees(-90), endAngle: .degrees(0), clockwise: false)
        self.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - bottomRightRadius))
        self.addArc(center: CGPoint(x: rect.maxX - bottomRightRadius, y: rect.maxY - bottomRightRadius),
                    radius: bottomRightRadius, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
        self.addLine(to: CGPoint(x: rect.minX + bottomLeftRadius, y: rect.maxY))
        self.addArc(center: CGPoint(x: rect.minX + bottomLeftRadius, y: rect.maxY - bottomLeftRadius),
                    radius: bottomLeftRadius, startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
        self.addLine(to: CGPoint(x: rect.minX, y: rect.minY + topLeftRadius))
        self.addArc(center: CGPoint(x: rect.minX + topLeftRadius, y: rect.minY + topLeftRadius),
                    radius: topLeftRadius, startAngle: .degrees(180), endAngle: .degrees(270), clockwise: false)
        self.closeSubpath()
    }
}

// MARK: - Typing Indicator with 🤖 and Animated Dots
struct TypingIndicator: View {
    @State private var animate = false

    var body: some View {
        HStack {
            HStack(spacing: 10) {
                Text("🤖")

                HStack(spacing: 6) {
                    ForEach(0..<3, id: \.self) { index in
                        Circle()
                            .fill(Color.black.opacity(0.6))
                            .frame(width: 8, height: 8)
                            .scaleEffect(animate ? 1.0 : 0.5)
                            .animation(
                                .easeInOut(duration: 0.6)
                                    .repeatForever()
                                    .delay(Double(index) * 0.2),
                                value: animate
                            )
                    }
                }
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 18)
            .background(Color.white)
            .foregroundColor(.black)
            .font(.system(size: 17, weight: .medium))
            .clipShape(ChatBubbleShape(isUser: false))
            .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)

            Spacer()
        }
        .padding(.horizontal, 12)
        .onAppear {
            animate = true
        }
    }
}

// MARK: - Preview
struct AIChatbot_Previews: PreviewProvider {
    static var previews: some View {
        AIChatbot(chatbotName: "NutriBot")
    }
}
